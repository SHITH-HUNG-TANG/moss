#include<iostream>
#include"s1083322_MyArray.h"
#include"s1083322_MyString.h"
using namespace std;

int main()
{
	MyString<char> str,str2,str4;
	char Str3[5] = { 'O','u','O','b'};
	cout << "****����>>��غc�l****" << endl;
	cout << "��Jstr" << endl;
	cin >> str;
	cout <<"str:"<<str << endl;
	cout << "��Jstr2" << endl;
	cin >> str2;
	cout <<"str2:"<<str2 << endl;
	cout << "str3���w�]�}�C" << endl;
	MyString<char>str3(Str3);
	cout << str3 << endl;
	cout << endl << endl;


	cout << "****����append****" << endl;
	cout << "str= " << str << endl;
	cout << "str2= " << str2 << endl;
	cout <<"str append str2"<< endl;
	str.append(str2);
	cout << "str= "<<str<< endl;
	cout << endl << endl;

	
	cout << "****����substr****" << endl;
	cout << "str= " << str << endl;
	str4 = str.substr(2, 2);
	cout << "str4=str(2,2)="<< str4 << endl;
	cout << endl << endl;
	
	cout << "****����insert****" << endl;
	cout << "str3= " << str3 << endl;
	cout << "str4= " << str4 << endl;
	cout << "�Nstr3���Jstr4��1��" << endl;
	str4.insert(1, str3);
	cout << "str4= " << str4 << endl;
	cout << "str2= " << str2 << endl;
	cout << "str3= " << str3 << endl;
	cout << "�Nstr3��2��}�l���Jstr2��1��" << endl;
	str2.insert(1, str3, 2, 2);
	cout << "str2= " << str2 << endl;
	cout << endl << endl;
	
	cout << "****����erase****" << endl;
	cout << "str2= " << str2 << endl;
	cout << "�M����贡�J����" << endl;
	str2.erase(1,2);
	cout << "str2= " << str2 << endl;
	cout << endl << endl;
	
	cout << "****����find&find first of****" << endl;
	cout << "str3= " << str3 << endl;
	cout << "str4= " << str4 << endl;
	cout << "find str3" << endl;
	cout << str4.find(str3, 0) << endl;
	cout << endl << endl;

	system("pause");
}