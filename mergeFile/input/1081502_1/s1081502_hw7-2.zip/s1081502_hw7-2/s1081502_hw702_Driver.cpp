#include<iostream>
#include<stdexcept>
#include"s1081502_MyString.h"
using namespace std;
int main()
{
    cout << "********************I am s1081502********************" << endl;
    cout << "********************Test Constructor********************" << endl;

    char char1[] = "Hello I am s1081502 ! ";
    MyString str1(char1);
    cout << "str1 = " << str1 << endl;
    cout << "ans  = Hello I am s1081502 !  " << endl;

    MyString str2(str1);
    cout << "str2 = " << str2 << endl;
    cout << "ans  = Hello I am s1081502 !  " << endl;

    MyString str3(str1, 0, 6);
    cout << "str3 = " << str3 << endl;
    cout << "ans  = Hello " << endl;

    MyString str4(str1, 6);
    cout << "str4 = " << str4 << endl;
    cout << "ans  = I am s1081502 ! " << endl;

    cout << endl;

    cout << "********************Test append********************" << endl;
    cout << "str3 = " << str3 << endl;
    cout << "ans  = Hello " << endl;
    cout << "str4 = " << str4 << endl;
    cout << "ans  = I am s1081502 ! " << endl;
    cout << "str3.append(str4) = " << str3.append(str4) << endl;
    cout << "ans               = Hello I am s1081502 ! " << endl;

    cout << endl;

    cout << "********************Test substr********************" << endl;
    cout << "str1 = " << str1 << endl;
    cout << "ans  = Hello I am s1081502 !  " << endl;
    cout << "str1.substr(6,4) = " << str1.substr(6, 4) << endl;
    cout << "ans              = I am" <<endl;
    cout << "str1.substr(6) = " << str1.substr(6) << endl;
    cout << "ans            = I am s1081502 ! " << endl;

    cout << endl;

    cout << "********************Test insert1********************" << endl;
    MyString str5("everyone ");
    cout << "str5 = " << str5 << endl;
    cout << "ans  = everyone " << endl;
    cout << "str1 = " << str1 << endl;
    cout << "ans  = Hello I am s1081502 ! " << endl;
    cout << "str1.insert(6,str5) = " << str1.insert(6, str5) << endl;
    cout << "ans                 = Hello everyone I am s1081502 ! " << endl;

    cout<< endl;

    cout << "********************Test insert2********************" << endl;
    MyString str6("Hello I am CSE1B s1081502 ! ");
    cout << "str6 = " << str6 << endl;
    cout << "ans  = Hello I am CSE1B s1081502 ! " << endl;
    cout << "str1 = " << str1 << endl;
    cout << "ans  = Hello everyone I am s1081502 ! " << endl;
    cout << "str1.insert(20, str6 ,11,6) = " << str1.insert(20, str6 ,11,6) << endl;
    cout << "ans                         = Hello everyone I am CSE1B s1081502 ! " << endl;

    cout << endl;

    cout << "********************Test erase********************" << endl;
    cout << "str1 = " << str1 << endl;
    cout << "ans  = Hello everyone I am CSE1B s1081502 ! " << endl;
    cout << "str1.erase(6,6) = " << str1.erase(6, 9) << endl;
    cout << "ans             = Hello I am CSE1B s1081502 !" << endl;
    cout << "str1.erase(6) = " << str1.erase(6) << endl;
    cout << "ans           = Hello " << endl;

    cout << endl;

    cout << "********************Test find********************" << endl;
    cout << "str6 = " << str6 << endl;
    cout << "ans  = Hello I am CSE1B s1081502 ! " << endl;
    cout << "str6.find(" << '"' << "CSE1B" << '"' << ") = " << str6.find("CSE1B") << endl;
    cout << "ans                = 11" << endl;
    cout << "str6.find(" << '"' << "yzu" << '"' << ") = ";
    if (str6.find("yzu") == 4294967295)
        cout << "not found " << endl;
    else
        cout << str6.find("yzu") << endl;
    cout << "ans              = not found " << endl;

    cout << endl;

    cout << "********************Test find_first_of********************" << endl;
    cout << "str6 = " << str6 << endl;
    cout << "ans  = Hello I am CSE1B s1081502 ! " << endl;
    cout << "str6.find_first_of(" << '"' << "150" << '"' << ") = " << str6.find_first_of("150") << endl;
    cout << "ans                       = 14" << endl;
    cout << "str6.find_first_of(" << '"' << "yzu" << '"' << ") = ";
    if (str6.find_first_of("yzu") == 4294967295)
        cout << "not found " << endl;
    else
        cout << str6.find_first_of("yzu") << endl;
    cout << "ans                       = not found " << endl;

    cout << endl;

    cout << "********************Test operator>>********************" << endl;
    MyString str7;
    cin >> str7;
    cout << str7 << endl;

}
