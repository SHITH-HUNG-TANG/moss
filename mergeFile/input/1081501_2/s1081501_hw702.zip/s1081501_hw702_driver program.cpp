#include<iostream>
#include"s1081501_MyString.h"
int main()
{
	cout << "I'm s1081501" << endl;
	cout << "----------------Test Constructor---------------------" << endl;
	char ch1[] = "oh my playstation5 ";
	char ch3[] = "i just want to test the big string i just want to test the big string i just want to test the big string i just want to test the big string i just want to test the big stringi just want to test the big stringi just want to test the big stringi just want to test the big stringi just want to test the big string";
	MyString   str1(ch1);
	cout << "str1 = " << str1 << endl;
	cout << " ans = " << "oh my playstation5 " << endl;
	MyString   str6(ch3);
	cout << "str6 = " << str6 << endl;
	cout << " ans = " << "i just want to test the big string i just want to test the big string i just want to test the big string i just want to test the big string i just want to test the big stringi just want to test the big stringi just want to test the big stringi just want to test the big stringi just want to test the big string" << endl;
	cout << "-----------------Test Copy Constructor---------------------" << endl;
	MyString str2(str1);
	cout << "str2 = " << str2 << endl;
	cout << " ans = " << "oh my playstation5 " << endl;
	cout << "----------------Test substr Constructor--------------------" << endl;
	MyString str4(str1, 3, 15);
	cout << "str4 = " << str4<<endl;
	cout << " ans = " <<"my playstation5" <<endl;
	char ch4[] = "oh my playstation5 I want to buy it";
	MyString str5(ch4);
	MyString str7(str5, 16);
	cout << "str7 = " << str7 << endl;
	cout << " ans = " << "n5 I want to buy it" << endl;
	cout << "----------------Test append---------------------" << endl;
	char ch2[] = "I want to buy it";
	MyString str3(ch2);
	cout << "str1.append(str3) = " << str1.append(str3) << endl;
	cout << "              ans = " << "oh my playstation5 I want to buy it" << endl;
	cout << "----------------Test insert function---------------------" << endl;
	char ch5[] = "i think is hurt ";
	char ch6[] = "my head ";
	MyString str8(ch5), str9(ch6);
	cout << "str8.insert(8, str9) = " << str8.insert(8, str9) << endl;
	cout << "                 ans = "<<"i think my head is hurt"<<endl;
	MyString str10(ch5), str11(ch6);
	cout << "str10.insert(8, str11,3,5) = " << str10.insert(8, str11, 3, 5) << endl;
	cout << "                       ans = " << "i think head is hurt" << endl;
	cout << "----------------Test substr function---------------------" << endl;
	cout << "str1 = " << str1 << endl;
	cout << "str1.substr(3, 15) = " << str1.substr(3, 15) << endl;
	cout << "               ans = " << "my playstation5" << endl;
	cout << "str1.substr(3) = " << str1.substr(3)   << endl;
	cout << "           ans = " << "my playstation5 I want to buy it" << endl;
	cout << "----------------Test erase function---------------------" << endl;
	MyString str12(ch4);
	cout << "str12 = " << str12 << endl;
	cout << "str12.erase(3,5) = " << str12.erase(3, 3) << endl;
	cout << "             ans = "<<"oh playstation5 I want to buy it "<<endl;
	cout << "----------------Test find function---------------------" << endl;
	char ch7[] = "playstation5";
	MyString str13(ch4);
	MyString str14(ch7);
	cout << "str13 = " << str13 << endl;
	cout << "str14 = " << str14 << endl;
	cout << "str13.find(str14) = " << str13.find(str14) << endl;
	cout << "              ans = 6" << endl;
	cout << "str13.find(str14,10) = ";
	if (str13.find(str14, 10)== 4294967295)
	{
		cout << "not find"<<endl;
	}
	cout << "                 ans = not find" << endl;
	cout << "----------------Test find_first_of function---------------------" << endl;
	char ch8[] = "hello";
	char ch9[] = "qooanndd";
	char ch10[] = "dqqqqqqqqqqe";
	MyString str15(ch8);
	MyString str16(ch9);
	MyString str17(ch10);
	cout << "str15 = " << str15 << endl;
	cout << "str16 = " << str16 << endl;
	cout << "str17 = " << str17 << endl;
	cout << "str16.find_first_of(str15) = " << str16.find_first_of(str15) << endl;
	cout << "                       ans = 1" << endl;
	cout << "str16.find_first_of(str15,5) = ";
	if (str16.find_first_of(str15, 5) == 4294967295)
	{
		cout << "not find" << endl;
	}
	cout << "                         ans = not find" << endl;
	cout << "str17.find_first_of(str15) = " << str17.find_first_of(str15) << endl;
	cout << "                       ans = 11" << endl;
	cout << "----------------Test operator>>---------------------" << endl;
	MyString str18;
	cin >> str18;
	cout << str18;
	system("pause");
}