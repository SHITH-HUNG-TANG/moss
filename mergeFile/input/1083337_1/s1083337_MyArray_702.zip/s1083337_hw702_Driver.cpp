#include<iostream>
#include "s1083337_MyString.h"

using namespace std;

int main() {

	cout << "s1083337 Driver program \n";
	cout << "\n************************************ Test Constructor *********************************\n";
	MyString n1 , n2("Hello") ,n3(n2) , n4(n3,1,3);
	cout <<"n1 =" <<n1 << endl;
	cout <<"n2(Hello) = " << n2 << endl;
	cout <<"n3(n2) =" <<n3 << endl;
	cout <<"n4(n3,1,3) = " <<n4 << endl;

	cout << "\n************************************ Append *********************************\n";
	n2.append(" world");
	cout << "n2.append( world) = "<<n2<<endl;
	n1.append(n2);
	cout << "n1.append(n2) = " << n1 << endl;

	cout << "\n************************************ Substr *********************************\n";
	cout << "n1 =" << n1<<endl;
	cout << "n1.substr(2,6) = " <<n1.substr(2, 6)<<endl ;
	cout << "n1 = " << n1 << endl;
	cout << "\n************************************ Insert *********************************\n";
	MyString n5("aaa");
	n1.insert( 7 ,n4);
	cout << "n1.insert(7,n4) = " << n1 << endl;
	n5.insert( 1 ,"bbbb" );
	cout << "n5.insert(1, bbbb) = " <<n5 << endl;
	n2.insert( 2, n5, 3, 3);
	cout <<"n2.insert(2,n5,3,3) = "<< n2<<endl;
	n3.insert(2, "xxxxyyy", 3, 3);
	cout << "n3.insert(2,xxxyyy,3,3) = " << n3 << endl;

	cout << "\n************************************ Erase *********************************\n";
	n1.erase(3, 3);
	cout << "n1.erase(3,3) = " << n1 << endl;
	n5.erase(4,10);
	cout << "n5.erase(4,10) = " << n5 << endl;


	cout << "\n************************************ Find && Find_first_of() *********************************\n";
	cout << "n1 = " << n1 << endl;
	cout <<"n1.find(wel,0) = "<<n1.find("wel", 0)<<endl;
	cout << "n1.find(abcd,0) = " << n1.find("abcd", 0) << endl;
	cout << "n1.find_first_of(ald,4) = " << n1.find_first_of("ald", 4) << endl;
	MyString n6("rld");
	cout << "\nn2 = " << n2 << endl;
	cout << "n5 = " << n5 << endl;
	cout << "n6 = " << n6 << endl;
	cout << "n2.find(n6,0) = " << n2.find(n6, 0) << endl;
	cout << "n2.find_first_of(n5,0) = " << n2.find_first_of(n5, 0) << endl;


	cout << "\n************************************ Exception handling *********************************\n";
	try
	{
		cout << n6.at(7) << endl;
	}
	catch (const std::out_of_range& oor)
	{
		cerr << "Out og Range error: " << oor.what() << endl;
	}

	cout << "\n************************************ operator >> *********************************\n";
	MyString n7;
	cin >> n7;
	cout <<"n7 = "<< n7<<endl;
	n7.append(n1);
	cout << "n7.append(n1) = " << n7 << endl;
	cout << "n7.substr(3,10) = " << n7.substr(3, 10) << endl;
	n7.insert( 1, n1, 1, 3);
	cout << "n7.insert(1,n1,1,3) = " << n7 << endl;
	n7.erase(2, 10);
	cout << "n7.erase(2,10) = " << n7 << endl;
	cout << "n7.find(n6,0) = " << n7.find(n6, 0) << endl;
	cout << "n7.find_first_of(n3,0) = " << n7.find_first_of(n3, 0) << endl;
}