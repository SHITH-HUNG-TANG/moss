#include"s1083334_MyString.h"


int main() {

	cout << "I'm 1083334." << endl << endl;

	MyString str1("hello this"), str2(" beautiful world");
	cout << "construct str1(\"hello this\")" << endl;
	cout << "construct str2(\" beautiful world\")" << endl;
	cout << "str1 = " << str1 << endl;
	cout << "str2 = " << str2 << endl;
	cout << endl << endl;

	MyString str3(str1, 0, 6);
	cout << "construct str3(str1, 0, 6)" << endl;
	cout << "str3 = " << str3 << endl;
	MyString str4(str2, 11);
	cout << "construct str4(str2, 11)" << endl;
	cout << "str4 = " << str4 << endl;
	cout << endl << endl;

	str1.append(str2);
	cout << "str1.append(str2)" << endl;
	cout << "str1 = " << str1 << endl;
	cout << endl << endl;

	str1.insert(6, str3);
	cout << "str1.insert(6, str3)" << endl;
	cout << "str1 = " << str1 << endl;
	str1.insert(16, str2, 0, 10);
	cout << "str1.insert(16, str2, 0, 10)" << endl;
	cout << "str1 = " << str1 << endl;
	cout << endl << endl;

	str1.erase(16, 10);
	cout << "str1.erase(16, 10)" << endl;
	cout << "str1 = " << str1 << endl;
	cout << endl << endl;

	cout << "str2.substr(1, 9)" << endl;
	cout << "str2 = " << str2.substr(1, 9) << endl;
	cout << endl << endl;

	MyString str6("zzz");
	cout << "str6 = " << str6 << endl;
	cout << "str1.find(str2, 3)" << endl;
	cout << str1.find(str2, 3) << endl;
	cout << "str1.find(str6)" << endl;
	cout << str1.find(str6) << endl;
	cout << endl << endl;

	cout << "str2.find_first_of(str4)" << endl;
	cout << str2.find_first_of(str4) << endl;
	cout << "str2.find_first_of(str6)" << endl;
	cout << str2.find_first_of(str6) << endl;
	cout << endl << endl;

	MyString str7;
	cout << "please enter a string." << endl;
	cin >> str7;
	cout << "str7 = " << str7 << endl;
	cout << endl << endl;

	system("pause");
	return 0;
}