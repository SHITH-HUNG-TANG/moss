#include"s1061637_Mystring.h"
int main()
{
	
	
	
	return 0;
}