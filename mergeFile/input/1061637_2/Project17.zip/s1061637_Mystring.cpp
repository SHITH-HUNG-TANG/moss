#include"s1061637_MyString.h"
#include<iostream>
#include <string>
using namespace std;
MyString::MyString() :MyArray(10) {}
MyString::MyString(const MyString &str)
{
	delete[]data;
	this->data = new char[str.capacity];
	capacity = str.capacity;
	for (size_t i = 0; i < str.size; i++)
		str.data[i] = str.data[i];
	size = str.size;
}
MyString::MyString(const MyString &str, size_t pos, size_t len)
{
	if (len > str.size|| str.size==-1)
		len = str.size - 1;
	delete[]data;
	this->data = new char[str.capacity];
	capacity = str.capacity;
	for (size_t i = 0, start = pos; i <= len; i++, start++)
	{
		str.data[i] = str.data[start];
		++size;	
	}
	
}
MyString::MyString(const char *s)
{
	int inputsize = 0;
	for (size_t i = 0; s[i] != '\0'; i++)
		++inputsize;
	capacity = inputsize;
	data = new char[inputsize];
	size = inputsize;
	//copy(s, s + inputsize, data);
}
MyString&  MyString::append(const MyString &str)
{
	MyArray::reserve(str.size+ MyArray::size);
	//copy(str.data , str.data+ str.size   , data+size);
	return *this;

}
MyString& MyString::insert(size_t pos, const MyString &str)
{
	MyArray::reserve(str.size + MyArray::size);
	int tempsize = size - pos;
	char* temp = new char[tempsize];
	//copy(data + pos, data + size, temp);
	//copy(str.data, str.data + str.size,data + pos);
	size = pos + str.size;
	//copy(temp, temp + tempsize, data + size - 1);
	return *this;
}

MyString& MyString::insert(size_t pos, const MyString&str, size_t subpos, size_t sublen)
{//�������O�}�C�j�p
	
	if (subpos+ sublen > str.size|| sublen==-1)
		sublen = str.size - subpos;
	if (size < pos + 1 || subpos> str.size-1)
		cout << "���ޭȶW�X�}�C";
	else
	{ 
     int tempsize = size - pos;
     MyArray::reserve(sublen + MyArray::size);
	 char* temp = new char[tempsize];
	 //copy(data+pos,data+size,temp);
	 //copy(str.data+subpos, str.data +subpos+sublen, MyArray::data+pos);
	 size = pos+sublen;
	 //copy(temp, temp + tempsize, data + size - 1);
	}
	return *this;
}
MyString & MyString::erase(size_t pos, size_t len)//pos�O��ڦ�m
{
	MyString right;
	right.reserve(this->size - len-pos+1);
	//copy(data+pos+ len-1, data+this->size, right);
	MyString left;
	left.reserve(pos-1);
	//copy(data , data +pos, left);
	this->reserve(right.size + left.size);
	this->size = 0;
	this->append(left).append(right);
	return *this;
}
	

MyString  MyString::substr(size_t pos, size_t len) const
{
	return MyString (*this,pos, len);
}

template <class T>
 /*istream &operator>>(istream & in, MyString& str)
{
	 string temp;
	 in >> temp;
	 str.reserve(temp.size());
	 for (size_t i = 0; i < temp.size(); i++)
	 {
		 str.data[i] = temp[i];
	 }
	 size = temp.size;

}*/
 ostream &operator<<(ostream & os, const MyString& str)
{
	 for (size_t i = str.size - 1; i >= 0; i++)
		 os << str.data[i];
	 return os;
}
 size_t MyString::find(const MyString &str, size_t pos = 0) const
 {
	 for (size_t i = pos - 1; i < this->size; i++)
	 {
		 for (size_t j = 0; i < str.size; j++)
		 {
			 if (this->data[i + j] != str.data[j])
				 break;
			 else
			 {
				 if (j == str.size - 1)
					 return i + 1;
			 }
		 }
	 }
	 return  MyString::msize;
 }
 size_t MyString::find_first_of(const MyString &str, size_t pos = 0) const
 {

	 for (size_t i = pos - 1; i < this->size; i++)
	 {
		 for (size_t j = 0; i < str.size; j++)
		 {
			 if (str[j] == this->data[i])
				 return  i + 1;
		 }
	 }
	 return  MyString::msize;
 }