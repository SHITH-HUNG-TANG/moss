#include<iostream>
#include <stdexcept>
#include <vector>
#include <iostream>
#include <stdexcept>
#include "Myarray.h"
#include "MyString.h"
using namespace std;

int main(int argc, char* argv[]) {

	cout << "s1083341" << endl;
	cout << "----------constructor----------" << endl;
	MyString n1;
	n1.resize(15, 'j');
	cout << "n1=" << n1 << endl;
	MyString n0(n1, 11, 3);
	cout << "n0=" << n0 << endl;
	MyString str1 = " victor";
	cout << "str1=" << str1 << endl << endl;
	cout << "----------append----------" << endl;
	MyString n2;
	cout << "n1=" << n1 << endl;
	n2 = n1.append(str1);
	cout << "n2=" << n2 << endl << endl;
	cout << "----------substr----------" << endl;
	MyString n3;
	n3 = n1.substr(14, 6);
	cout << "n1=" << n1 << endl;
	cout << "n3=" << n3 << endl << endl;
	cout << "----------insert----------" << endl;
	MyString n4;
	cout << "n1=" << n1 << endl;
	n4 = n1.insert(2, str1);
	cout << "n4=" << n4 << endl << endl;
	MyString n5;
	cout << "n1=" << n1 << endl;
	n5 = n1.insert(2, str1, 2, 3);
	cout << "n5=" << n5 << endl << endl;
	cout << "----------erase----------" << endl;
	MyString n6;
	cout << "n1=" << n1 << endl;
	n6 = n1.erase(2, 10);
	cout << "n6=" << n6 << endl << endl;
	cout << "----------find/find_first_of----------" << endl;
	size_t findd;
	cout << "n1=" << n1 << endl;
	findd = n1.find("writing");
	if (findd != -1)
		cout << "find writing in the STR :" << findd << endl;
	else
		cout << "can not find writing in the STR :" << endl;
	cout << endl;
	MyString n7 = "to be or not to be, that is cool question.";
	cout << "n7=" << n7 << endl;
	findd = n7.find_first_of("cxxl");
	if (findd != -1)
		cout << "find cxxl in the STR :" << findd << endl;
	else
		cout << "can not find cxxl in the STR." << endl;
	cout << endl;

	cout << "----------operator>>/operator<<----------" << endl;
	MyString n8;
	cout << "input n8:";
	cin >> n8;
	cout << "n8=" << n8 << endl;
	cout << endl;

	cout << "----------Exception handling----------" << endl;
	MyArray<int>myvector(10);
	try {
		cout << myvector.at(30) << endl;
	}
	catch (const MyArray<int>::Error& oor) {
		cerr << "Out of Range error: " << oor.what() << '\n';
	}

	return 0;
}

