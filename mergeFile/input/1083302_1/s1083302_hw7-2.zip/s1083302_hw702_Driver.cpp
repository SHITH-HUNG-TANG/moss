#include"s1083302_MyString.h"
#include<iostream>
#include<ostream>
#include<exception>
using namespace std;

int main()
{
	cout << "Hi I am 1083302" << endl;

	cout << "***** Constructor / Destructor *****" << endl << endl;
	const char* z = "xxxyyyzz";
	MyString n1(z);
	cout << "n1 = "<< n1 << endl;
	MyString n2(n1,3);
	cout << "n2 = " << n2 << endl;

	cout << endl << "***** apend(...) *****" << endl << endl;
	const char* s = "aaaaabbbbbbb" ;
	const char* a = "cccc";
	MyString n3(s), n4(a);
	cout << "n3 = " << n3 << endl;
	cout << "n4 = " << n4 << endl;
	cout << "n3.append(n4): " << n3.append(n4) << endl;;
	cout << "n3 = " << n3 << endl;

	cout << endl << "***** substr *****" << endl << endl;
	cout << "n3 = " << n3 << endl;
	cout << "n3.substr(2,5) : " << n3.substr(2, 5) << endl;
	cout << "n3.substr(5)" << n3.substr(5) << endl;

	cout << endl << "***** insert *****" << endl << endl;
	const char* h = "hihihi";
	const char* d = "kkkkk";
	MyString n5(h), n6(d);
	cout << "n4 = " << n4 << endl;
	cout << "n5 = " << n5 << endl;
	cout << "n5.insert(2, n4): " << n5.insert(2, n4) << endl;
	cout << "n5 = " << n5 << endl;
	cout << "n6 = " << n6 << endl;
	cout << "n6.insert(2, n4, 1, 2): " << n6.insert(2, n4, 1, 2) << endl;

	cout << endl << "***** erase *****" << endl;
	cout << "n6 = " << n6 << endl;
	cout << "n6.erase(2, 3): " << n6.erase(2, 3) << endl;

	cout << endl << "***** find() and find_first_of() *****" << endl;
	const char* x = "yyabcxxx";
	const char* y = "bcx";
	MyString n7(x), n8(y);
	cout << "n7 = " << n7 << endl;
	cout << "n8 = " << n8 << endl;
	cout << "n7.find(n8): " << n7.find(n8) << endl;
	cout << "n7.find_first_of(n8, 1): " << n7.find_first_of(n8, 1) << endl;

	cout << endl << "***** operator>>, operator<< *****" << endl;
	MyString n9;
	cout << "input n9 : ";
	cin >> n9;
	cout << "n9 = " << n9 << endl;

	cout << endl << "***** Exception handling *****" << endl;
	const char* j = "qwertyi";
	MyString n10(j);
	cout << "n10 = " << n10 << endl;
	try
	{
		cout << "n10 = " << n10 << endl;
		cout << "n14[4] = ";
		cout << n10.at(4);
	}
	catch (at_exception & out)
	{
		cerr << " n10[4] is " << out.what() << endl;
	}
	cout << endl;
	try
	{
		cout << "n10 = " << n10 << endl;
		cout << "n10[9] = ";
		cout << n10.at(9);
	}
	catch (at_exception & out)
	{
		cerr << "n10[9] is " << out.what() << endl;
	}

}