#include"s1081545_MyString.h"

int main()
{
	char str1[] = "YuanZe University";
	MyString objStrA, objStrB(str1), objStrC(objStrB), objStrD(objStrB, 7, 10);
	cout << "objStrA(): capacity = " << objStrA.getCapacity() << ", size = " << objStrA.getSize() << endl;
	cout << "\tdata = " << objStrA << endl;
	cout << "objStrB(char*): capacity = " << objStrB.getCapacity() << ", size = " << objStrB.getSize() << endl;
	cout << "\tdata = " << objStrB << endl;
	cout << "objStrC(obj): capacity = " << objStrC.getCapacity() << ", size = " << objStrC.getSize() << endl;
	cout << "\tdata = " << objStrC << endl;
	cout << "objStrD(obj,st,len): capacity = " << objStrD.getCapacity() << ", size = " << objStrD.getSize() << endl;
	cout << "\tdata = " << objStrD << endl;

	char str2[] = "Computer Science and Engineering @ ";
	MyString objStrE(str2);
	cout << "objStrE(str): capacity = " << objStrE.getCapacity() << ", size = " << objStrE.getSize() << endl;
	cout << "\tdata = " << objStrE << endl;
	objStrE.append(objStrB);
	cout << "objStrE(str): capacity = " << objStrE.getCapacity() << ", size = " << objStrE.getSize() << endl;
	cout << "\tdata = " << objStrE << endl;

	MyString objStrF = objStrE.substr(9, 23);
	cout << "objStrE.substr(9, 23): capacity = " << objStrF.getCapacity() << ", size = " << objStrF.getSize() << endl;
	cout << "\tdata = " << objStrF << endl;

	char str3[] = "Information ";
	MyString objStrG(str3);
	objStrE.insert(21, objStrG);
	cout << "objStrE.insert(): capacity = " << objStrE.getCapacity() << ", size = " << objStrE.getSize() << endl;
	cout << "\tdata = " << objStrE << endl;

	char str4[] = "Artificial Intelligence and System Integration";
	MyString objStrH(str4);
	objStrE.insert(21, objStrH, 11, 13);
	cout << "objStrE.insert(substr): capacity = " << objStrE.getCapacity() << ", size = " << objStrE.getSize() << endl;
	cout << "\tdata = " << objStrE << endl;

	objStrE.erase(34, 12);
	cout << "objStrE.erase(): capacity = " << objStrE.getCapacity() << ", size = " << objStrE.getSize() << endl;
	cout << "\tdata = " << objStrE << endl << endl;

	MyString objSubStr("Int");
	int pos11 = objStrH.find(objSubStr, 0);
	int pos12 = objStrH.find(objSubStr, pos11 + 1);
	int pos13 = objStrH.find(objSubStr, pos12 + 1);
	cout << "In the string \"Artificial Intelligence and System Integration\", " << endl;
	cout << "\tthe first position of substring \"Int\" is " << pos11 << ", the next position is " << pos12 << ", and next is " << pos13 << endl << endl;

	MyString objStrChr("god");
	int nCnt = 0, pos = objStrH.find_first_of(objStrChr, 0);
	while (pos >= 0)
	{
		nCnt++;
		pos = objStrH.find_first_of(objStrChr, pos + 1);
	}
	cout << "In the string \"Artificial Intelligence and System Integration\", " << endl;
	cout << "\tthe number of character in \"god\" is " << nCnt << endl << endl;

	cout << "Enter test string: ";
	MyString objInput;
	cin >> objInput;
	cout << "Your input: capacity = " << objInput.getCapacity() << ", size = " << objInput.getSize() << endl;
	objInput.shrink_to_fit();
	cout << "After shrinking...\n" << "Your input: capacity = " << objInput.getCapacity() << ", size = " << objInput.getSize() << endl;
	cout << "\tdata = " << objInput << endl << endl;
	cout << "input[1]=" << objInput[1] << ", Input.at(len-1)=" << objInput.at(objInput.getSize() - 1) << endl;
	cout << "Input.at(-1)=";
	try { cout << objInput.at(-1) << endl; }
	catch (out_of_range& oor) { cerr << oor.what() << endl; }
	cout << "Input[len]=";
	try { cout << objInput.at(objInput.getSize()) << endl; }
	catch (out_of_range& oor) { cerr << oor.what() << endl; }
	cout << endl;

	system("pause");
}