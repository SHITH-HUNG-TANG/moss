#include <iostream>
using namespace std;
#include "s1061643_MyString.h"

int main()
{
	cout << "Hi, I am 1061643" << endl;
	
	MyString str0, str1("We think in generalities, but we live in details."), str2(str1), str3(str1, 3, 5);
	cout << "=======Constructor ========" << endl;
	cout << "str0 = " << str0;
	cout << "str0 size = " << str0.getSize() << endl;
	cout << "str0 capacity = " << str0.getCapacity() << endl << endl;

	cout << "str1 = " << str1;
	cout << "str1 size = " << str1.getSize() << endl;
	cout << "str1 capacity = " << str1.getCapacity() << endl << endl;

	cout << "str2 = " << str2;
	cout << "str2 size = " << str2.getSize() << endl;
	cout << "str2 capacity = " << str2.getCapacity() << endl << endl;

	cout << "str3 = " << str3;
	cout << "str3 size = " << str3.getSize() << endl;
	cout << "str3 capacity = " << str3.getCapacity() << endl << endl;

	cout << "=======append========" << endl;
	cout << "str2 = " << str2;
	cout << "str2 size = " << str2.getSize() << endl;
	cout << "str2 capacity = " << str2.getCapacity() << endl << endl;
	cout << "str2.append(str3) = " << str2.append(str3) << endl;
	cout << "str2 size = " << str2.getSize() << endl;
	cout << "str2 capacity = " << str2.getCapacity() << endl << endl;

	cout << "=======substr========" << endl;
	cout << "str0 = " << str0;
	cout << "str0 size = " << str0.getSize() << endl;
	cout << "str0 capacity = " << str0.getCapacity() << endl << endl;
	str0 = str1.substr(2, 13);
	cout << "str0 = str1.substr(2, 13) = " << str0  << endl;
	cout << "str0 size = " << str0.getSize() << endl;
	cout << "str0 capacity = " << str0.getCapacity() << endl << endl;

	cout << "=======insert(size_t pos, const MyString &str)========" << endl;
	MyString str4("happy cool ");
	cout << "str0 = " << str0;
	cout << "str0 size = " << str0.getSize() << endl;
	cout << "str0 capacity = " << str0.getCapacity() << endl << endl;
	str0.insert(3, str4);
	cout << "str0.insert(3, str4) = " << str0 << endl;
	cout << "str0 size = " << str0.getSize() << endl;
	cout << "str0 capacity = " << str0.getCapacity() << endl << endl;

	cout << "=======insert(size_t pos, const MyString &str, size_t subpos, size_t sublen = msize)========" << endl;
	MyString str5("abcdefghijklmnopqrstuvwxyz");
	MyString str6("cc f");
	cout << "str6 = " << str6;
	cout << "str6 size = " << str6.getSize() << endl;
	cout << "str6 capacity = " << str6.getCapacity() << endl << endl;
	str6.insert(3, str5, 1, 23);
	cout << "str6.insert(3, str5, 1, 2) = " << str6;
	cout << "str6 size = " << str6.getSize() << endl;
	cout << "str6 capacity = " << str6.getCapacity() << endl << endl;

	cout << "=======erase========" << endl;
	MyString str7("This is an example sentence.");
	cout << "str7 = " << str7;
	cout << "str7 size = " << str7.getSize() << endl;
	cout << "str7 capacity = " << str7.getCapacity() << endl << endl;
	str7.erase(10, 8);
	cout << "str7.erase(10, 8) = " << str7;
	cout << "str7 size = " << str7.getSize() << endl;
	cout << "str7 capacity = " << str7.getCapacity() << endl << endl;

	cout << "=======find========" << endl;
	MyString str8("There are two needles in this haystack with needles.");
	MyString str9("needle");
	cout << "str8.find(str9):" << endl;
	cout << "First needle is at " << str8.find(str9) << endl;
	cout << "str8.find(str9, 15):" << endl;
	cout << "Second needle is at " << str8.find(str9, 15) << endl << endl;

	cout << "=======find_first_of========" << endl;
	MyString str10("aeiou");
	cout << "str8.find_first_of(str10): " << str8.find_first_of(str10) << endl << endl;

	cout << "=======operator>>========" << endl;
	MyString str11;
	cin >> str11;
	cout << "str11 = " << str11;
	cout << "str11 size = " << str11.getSize() << endl;
	cout << "str11 capacity = " << str11.getCapacity() << endl << endl;

	system("pause");
}