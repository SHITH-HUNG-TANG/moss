#include<iostream>
#include<exception>
#include<string>
#include <stdexcept> 
#include"MyString_hw702.h"
//#include"hw7-1.cpp"
//#include"MyString_hw702.h"
using namespace std;
int main() {

	MyString s1;
	cin >> s1;
	cout << s1;

	MyString s2("abcdefghijk"),s3;
	cout <<"s2:"<< s2 << endl;

	cout << "s2.append(s1):"<<s2.append(s1) << endl;
	
	cout <<"s2.substr(8,11):"<<s2.substr(8,11) << endl;

	cout <<"s2.insert(3, s1):"<<s2.insert(3, s1)<< endl;

	cout << "s2.insert(3,s1,1,2):"<< s2.insert(3, s1, 1, 2) << endl;
	cout << s2 << endl;
	cout <<"s2.erase(1, 2):"<<s2.erase(1, 2)<< endl;

	cout <<"s2.find(s1, 2):"<<s2.find(s1, 2)<< endl;
	cout <<"s2.find_first_of(s1, 2):"<< s2.find_first_of(s1, 2) << endl;
}