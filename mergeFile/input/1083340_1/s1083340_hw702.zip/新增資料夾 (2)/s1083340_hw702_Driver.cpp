#include<iostream>
#include<stdexcept>
#include<string>
#include"s1083440_MyString.h"
using namespace std;
int main() {

	cout << " 1083340 " << endl;

	cout << "----------MyString(const char* s)----------" << endl;
	MyString strA (" abcd"),strB("abcdefghijk");
	cout << "ans: abcd" << endl;
	cout << "    "<< strA << endl;
	cout << "ans:abcdefghijk" << endl;
	cout << "    "<< strB << endl;
	cout << endl;

	cout << "----------MyString(const MyString& str, size_t pos, size_t len = msize)----------" << endl;
	try {
		MyString str1(strA, 3, 2);
		cout << "ans:cd" << endl;
		cout << "    " << str1 << endl;
	}
	catch (const out_of_range & oor) {
		cerr << "Out of Range error: " << oor.what() << endl;
	}
	try {
		MyString str2(strA, 3, 4);
		cout << "ans:cd" << endl;
		cout << "    " << str2 << endl;
	}
	catch (const out_of_range & oor) {
		cerr << "Out of Range error: " << oor.what() << endl;
	}
	try {
		MyString str3(strA, 5, 2);
		cout << "    " << str3 << endl;
	}
	catch(const out_of_range & oor){
		cerr << "Out of Range error: " << oor.what() << endl;
	}
	cout << endl;

	cout << "----------MyString& append(const MyString& str)----------" << endl;
	cout << "ans:abcdefghijk abcd" << endl;
	cout << "    "<< strB.append(strA) << endl;
	cout << "ans:abcdefghijk abcdabcdefghijk abcd" << endl;
	cout << "    " << strB.append(strB) << endl;
	cout << endl;

	cout << "----------MyString substr(size_t pos, size_t len = msize) const----------" << endl;
	MyString str4;
	cout << "hijk abcd" << endl;
	cout << (str4 = strB.substr(7, 9)) << endl;
	cout << endl;

	cout << "----------MyString& insert(size_t pos, const MyString& str)----------" << endl;
	MyString str5("to be question"),str6("the "),str7("happy day"),str8("birth");
	cout << "ans:to be the question" << endl;
	cout << "    "<< str5.insert(6, str6) << endl;
	cout << "ans:happy birthday" << endl;
	cout << "    " << str7.insert(6, str8) << endl;
	cout << endl;

	cout << "----------MyString& insert(size_t pos, const MyString& str, size_t subpos, size_t sublen = msize)----------" << endl;
	MyString str9("or not to be"), str10("happy  ");
	cout << "ans:to be not the question" << endl;
	cout << "    "<< str5.insert(6, str9, 3, 4) << endl;
	cout << "ans:happy or not" << endl;
	cout << "    "<< str10.insert(6, str9, 0, 6) << endl;
	cout << endl;

	cout << "----------MyString& erase(size_t pos, size_t len = msize)----------" << endl;
	cout << "ans:or not" << endl;
	cout << "    "<< str9.erase(7, 6) << endl;
	cout << "ans:bir" << endl;
	cout << "    "<< str8.erase(3, 3) << endl;
	cout << endl;

	cout << "----------size_t find(const MyString& str, size_t pos = 0) const----------" << endl;
	MyString str11("to be or not to be, that is c question coo"), str12("to be or not to be, that is cool question");
	cout << "ans:-1" << endl;
	cout << "    " << str11.find("cool", 0) << endl;
	cout << "ans:28" << endl;
	cout << "    " << str12.find("cool", 4) << endl;
	cout << endl;

	cout << "----------size_t find_first_of(const MyString& str, size_t pos = 0) const----------" << endl;
	cout << "ans:28" << endl;
	cout << "    " << str11.find_first_of("cxxl",2) << endl;
	cout << "ans:6" << endl;
	cout << "    " << str11.find_first_of("cool", 4) << endl;
	cout << "ans:-1" << endl;
	cout << "    " << str11.find_first_of("xyzg", 50) << endl;
	cout << "ans:-1" << endl;
	cout << "    " << str11.find_first_of("xyzg", 15) << endl;
	cout << endl;

	cout << "----------friend istream &operator>>(istream& input, MyString& str)----------" << endl;
	MyString str13;
	cin >> str13;
	cout << str13 << endl;
	cout << endl;
	cout << "Finish" << endl;

	return 0;
}
