#include<iostream>
#include"s1083305_MyArray.h"
#include"MyString_hw702.h"
using namespace std;

int main()
{
	cout << "I am s1083305.\n";

	cout << endl;
	const char* x = "hi";

	const char* y = "This sentence missing a verb.";
	const char* z = "is ";
	MyString a1(x), a2(y), a3(z);
	MyString cons(a1);
	cout << "This is a1 : " << a1 << endl;
	cout << endl;
	cout << "MyString(const MyString& a1)'s cons : " << cons << endl;
	cout << endl;
	cout << "This is a2 : " << a2 << endl;
	cout << endl;
	cout << "This is a3 : " << a3 << endl;
	cout << endl;
	cout << "a2 append a3 : " << a2.append(a3) << endl;
	cout << endl;
	cout << "a2 insert a3 : " << a2.insert(14,a3) << endl;

	MyString tmp = "happy new year";
	cout << tmp << endl;
	cout << tmp.substr(6,4) << endl;

	cout << endl;
	cout << tmp.erase(6, 4) << endl;

	cout << endl;

	MyString q = "yerewr";
	MyString a5 = "happy year";

	cout << tmp.find(q) << endl;
	cout << tmp.find_first_of(q) << endl;
	MyString c;
	cin >> c;
	cout << c;
	//char x[15] = { "to be question" };
	//char y[5] = { "the " };
	//char z[19] = { "to be the question" };
	//char p[13] = { "or not to be" };
	//const char* g = "asdfasdasdas";
	//MyString a1(x), a2(y),str(z),str3(p),str6(g);
	//cout << a1 << endl;
	//cout << a2 << endl;
	//cout << a1.insert(6, a2) << endl;
	//cout << str.insert(6, str3, 3, 4) << endl;
	//cout << str.erase(6, 4) << endl;
	//cout << str6 << endl;
	//const char* q = "to be or not to be, that is cool question";
	//const char* w = "boXL";
	//MyString Str(q),Str1(w);
	//cout << Str << endl;
	//cout << Str1 << endl;
	//cout << Str.find(Str1) << endl;
	//cout << Str.find_first_of(Str1) << endl;
	//cout << "I am s1083305.\n";
	//MyArray<int> n;
	//cout << "n = " << n << endl;
	//cout << "n capacity = " << n.getCapacity() << endl;
	//MyArray<int> n1(5,1), n2(5,2), n3(10,3), n5(15,5);
	//n1.resize(150, 3);
	//cout << n1;
	//cout << "n1 = " << n1 << endl;
	//cout << "n1 capacity = " << n1.getCapacity() << endl;
	//cout << "n2 = " << n2 << endl;
	//cout << "n2 capacity = " << n2.getCapacity() << endl;
	//cout << "n3 = " << n3 << endl;
	//cout << "n3 capacity = " << n3.getCapacity() << endl;
	//cout << "n5 = " << n5 << endl;
	//cout << "n5 capacity = " << n5.getCapacity() << endl;
	//cout << "------------------------operator+--------------------\n";
	//cout << "n1 + n2 = " << n1 + n2 << endl;
	//cout << "------------------------operator+= --------------------\n";
	//cout << "n3 += n5 = " << (n3 += n5) << endl;
	//cout << "------------------------operator=--------------------\n";
	//cout << "n1 = n2 : n1 = " << (n1 = n2) << endl;

	//cout << "------------------------shrink to fit--------------------\n";
	//n2.shrink_to_fit();
	//cout << "n2 shrink to fit : \nn2 capacity = " << n2.getCapacity() << endl;

	//cout << "------------------------clear--------------------\n";
	//n2.clear();
	//cout << "n2 clear : \n";
	//cout << "n2 size = " << n2.getSize() << endl;
	//cout << "n2 capacity = " << n2.getCapacity() << endl;
	//cout << "n2 = " << n2 << endl;

	//cout << "------------------------isEmpty--------------------\n";
	//cout << "n2 = " << n2 << endl;
	//cout << "Whether n2 is empty : ";
	//if (n2.isEmpty())
	//	cout << "true\n";
	//else
	//	cout << "false\n";

	//cout << "n1 = " << n1 << endl;
	//cout << "Whether n1 is empty : ";
	//if (n1.isEmpty())
	//	cout << "true\n";
	//else
	//	cout << "false\n";

	//cout << "------------------------at--------------------\n";
	//cout << "n3 = " << n3 << endl;
	//cout << "n3[3] = " << n3[3] << endl;
	//cout << "n3[100] = " << n3[100] << endl;


	//MyArray<char> a;
	//cout << "a = " << a << endl;
	//cout << "a capacity = " << a.getCapacity() << endl;
	//MyArray<char> a1(1, 'A'), a2(5, 'B'), a3(10, 'C'), a5(15, 'D');
	//cout << "a1 = " << a1 << endl;
	//cout << "a1 capacity = " << a1.getCapacity() << endl;
	//cout << "a2 = " << a2 << endl;
	//cout << "a2 capacity = " << a2.getCapacity() << endl;
	//cout << "a3 = " << a3 << endl;
	//cout << "a3 capacity = " << a3.getCapacity() << endl;
	//cout << "a5 = " << a5 << endl;
	//cout << "a5 capacity = " << a5.getCapacity() << endl;
	//cout << "------------------------operator+--------------------\n";
	//cout << "a1 + a2 = " << a1 + a2 << endl;
	//cout << "------------------------operator+= --------------------\n";
	//cout << "a3 += a5 = " << (a3 += a5) << endl;
	//cout << "------------------------operator=--------------------\n";
	//cout << "a1 = a2 : a1 = " << (a1 = a2) << endl;

	//cout << "------------------------shrink to fit--------------------\n";
	//a2.shrink_to_fit();
	//cout << "a2 shrink to fit : \na2 capacity = " << a2.getCapacity() << endl;

	//cout << "------------------------clear--------------------\n";
	//a2.clear();
	//cout << "a2 clear : \n";
	//cout << "a2 size = " << a2.getSize() << endl;
	//cout << "a2 capacity = " << a2.getCapacity() << endl;
	//cout << "a2 = " << a2 << endl;

	//cout << "------------------------isEmpty--------------------\n";
	//cout << "a2 = " << a2 << endl;
	//cout << "Whether a2 is empty : ";
	//if (a2.isEmpty())
	//	cout << "true\n";
	//else
	//	cout << "false\n";

	//cout << "a1 = " << a1 << endl;
	//cout << "Whether a1 is empty : ";
	//if (a1.isEmpty())
	//	cout << "true\n";
	//else
	//	cout << "false\n";

	//cout << "------------------------at--------------------\n";
	//cout << "a3 = " << a3 << endl;
	//cout << "a3[3] = " << a3[3] << endl;
	//cout << "a3[15] = " << a3[15] << endl;


	return 0;
}