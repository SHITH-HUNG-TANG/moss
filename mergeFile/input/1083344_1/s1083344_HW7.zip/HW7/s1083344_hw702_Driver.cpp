#include <iostream>
#include "s1083344_MyString.h"

using namespace std;

int main()
{
	MyString n1("applesss"), n2(n1), n3(n1, 0, 5), n4, n5("banana");

	cout << "/*----------------------------- Constructor --------------------------------*/" << endl << endl;
	cout << "n1 = " << n1 << endl;
	cout << "n2 = " << n2 << endl;
	cout << "n3 = " << n3 << endl;

	cout << "/*----------------------------- Operator>> --------------------------------*/" << endl << endl;
	cout << "Please input n4 : ";
	cin >> n4;
	cout << "\nn4 = " << n4 << endl;

	cout << "/*----------------------------- append() --------------------------------*/" << endl << endl;
	cout << "n4 = n4 + n5 = " << n4.append(n5) << endl;

	cout << "/*----------------------------- insert() --------------------------------*/" << endl << endl;
	cout << "Insert apple between apple and sss : " << n1.insert(5, n3) << endl;

	cout << "/*----------------------------- substr() --------------------------------*/" << endl << endl;
	cout << "Subtract ple from applesss : " << n1.substr(2, 3) << endl;

	cout << "/*----------------------------- erase() --------------------------------*/" << endl << endl;
	cout << "Erase sss from applesss : " << endl;
	n1.erase(5);
	cout << "n1 = " << n1 << endl;

	cout << "/*----------------------------- find() and find_first_of() --------------------------------*/" << endl << endl;
	MyString sentence("Sugar-free Green Tea");
	cout << "Output the position of Green : " << sentence.find("Green") << endl;
	cout << "Output the first position of gar : " << sentence.find_first_of("gar") << endl;

}