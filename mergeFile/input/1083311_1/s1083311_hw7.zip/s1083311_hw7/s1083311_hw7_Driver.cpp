#include "s1083311_MyArray.h"
#include "s1083311_MyString.h"
#include <iostream>
#include <stdexcept>
#include <string>
using namespace std;

int main()
{
	cout << "-------- default constructor ----------" << endl;
	MyArray <char> test1(200);
	cout << " Capacity = " << test1.getCapacity() << endl; //make sure capacity = 10

	cout << "\n------ constructor(int size , T value) -------" << endl;
	MyArray <char> test2(60, 'a');
	MyArray <char> test3(4, 'b');
	MyArray <char> test4(23, 'c');
	MyArray <char> test5(37, 'd');
	MyArray <int> test6(16, 5);
	MyArray <int> test7(21, 4);
	
	cout << "Test2 : ";
	for (int i = 0; i < test2.getSize(); i++)
		cout << test2.at(i);
	cout << " \nSize = " << test2.getSize() << endl;
	cout << "Capacity = " << test2.getCapacity() << endl; //make sure shrink function

	cout << "\nTest3 : ";
	for (int i = 0; i < test3.getSize(); i++)
		cout << test3.at(i);
	cout << " \nSize = " << test3.getSize() << endl;
	cout << "Capacity = " << test3.getCapacity() << endl; //make sure shrink function

	cout << "\nTest4 : ";
	for (int i = 0; i < test4.getSize(); i++)
		cout << test4.at(i);
	cout << " \nSize = " << test4.getSize() << endl;
	cout << "Capacity = " << test4.getCapacity() << endl; //make sure shrink function

	cout << "\nTest5 : ";
	for (int i = 0; i < test5.getSize(); i++)
		cout << test5.at(i);
	cout << " \nSize = " << test5.getSize() << endl;
	cout << "Capacity = " << test5.getCapacity() << endl; //make sure shrink function

	cout << "\nTest6 : ";
	for (int i = 0; i < test6.getSize(); i++)
		cout << test6.at(i);
	cout << " \nSize = " << test6.getSize() << endl;
	cout << "Capacity = " << test6.getCapacity() << endl; //make sure shrink function

	cout << "\nTest7 : ";
	for (int i = 0; i < test7.getSize(); i++)
		cout << test7.at(i);
	cout << " \nSize = " << test7.getSize() << endl;
	cout << "Capacity = " << test7.getCapacity() << endl; //make sure shrink function

	cout << "\n--------------operator<< ----------------\n";
	if (test1.isEmpty())
		cout << "Test1 : Empty" << endl;
	cout << "Test2 : " << test2 << endl;
	cout << "Test3 : " << test3 << endl;
	cout << "Test4 : " << test4 << endl;
	cout << "Test5 : " << test5 << endl;
	cout << "Test6 : " << test6 << endl;
	cout << "Test7 : " << test7 << endl;

	cout << "\n--------------operator= -----------------\n";
	test1 = test3;
	cout << "Test1 = Test3 : " << test1 << endl;
	test2 = test4;
	cout << "Test2 = Test4 : " << test2 << endl;
	cout << "Test3 : " << test3 << endl;
	cout << "Test4 : " << test4 << endl;
	cout << "Test5 : " << test5 << endl;
	cout << "Test6 : " << test6 << endl;
	cout << "Test7 : " << test7 << endl;

	cout << "\n--------------operator+ -----------------\n";
	cout << "Test1 + Test2 : " << test1 + test2 << endl;
	cout << "Test2 + Test3 : " << test2 + test3 << endl;
	cout << "Test4 + Test5 : " << test4 + test5 << endl;
	cout << "Test5 + Test1 : " << test5 + test1 << endl;
	cout << "Test4 + Test3 : " << test4 + test3 << endl;
	cout << "Test6 + Test7 : " << test6 + test7 << endl;

	cout << "\n--------------operator+= & shrink_to_fit -----------------\n";
	test1 += test2;
	cout << "Test1 += Test2 : " << test1 << endl;
	cout << "Size = " << test1.getSize() << endl;
	cout << "Capacity = " << test1.getCapacity() << endl; //make sure shrink function

	test2 += test5;
	cout << "\nTest2 += Test5 : " << test2 << endl;
	cout << "Size = " << test2.getSize() << endl;
	cout << "Capacity = " << test2.getCapacity() << endl; //make sure shrink function

	test3 += test2;
	cout << "\nTest3 += test2 : " << test3 << endl;
	cout << "Size = " << test3.getSize() << endl;
	cout << "Capacity = " << test3.getCapacity() << endl; //make sure shrink function

	test4 += test1;
	cout << "\nTest4 += Test1 : " << test4 << endl;
	cout << "Size = " << test4.getSize() << endl;
	cout << "Capacity = " << test4.getCapacity() << endl; //make sure shrink function

	test5 += test3;
	cout << "\nTest5 += Test3 : " << test5 << endl;
	cout << "Size = " << test5.getSize() << endl;
	cout << "Capacity = " << test5.getCapacity() << endl; //make sure shrink function

	test6 += test7;
	cout << "\nTest6 += Test7 : " << test6 << endl;
	cout << "Size = " << test6.getSize() << endl;
	cout << "Capacity = " << test6.getCapacity() << endl; //make sure shrink function

	cout << "\n--------------clear() & isEmpty()-----------------\n";
	test1.clear();
	if (test1.isEmpty())
		cout << "Test1 : Empty" << endl;
	cout << "Size = " << test1.getSize() << endl;
	cout << "Capacity = " << test1.getCapacity() << endl; //make sure shrink function

	test2.clear();
	if (test2.isEmpty())
		cout << "\nTest2 : Empty" << endl;
	cout << "Size = " << test2.getSize() << endl;
	cout << "Capacity = " << test2.getCapacity() << endl; //make sure shrink function

	test3.clear();
	if (test3.isEmpty())
		cout << "\nTest3 : Empty" << endl;
	cout << "Size = " << test3.getSize() << endl;
	cout << "Capacity = " << test3.getCapacity() << endl; //make sure shrink function

	cout << "\n--------------at() & Exception handling-----------------\n";
	cout << "Test4 : ";
	for (int i = 0; i < test4.getSize(); i++)
		cout << test4.at(i);
	cout << " \nSize = " << test4.getSize() << endl;
	cout << "Capacity = " << test4.getCapacity() << endl; //make sure shrink function

	cout << "\nTest5 : ";
	for (int i = 0; i < test5.getSize(); i++)
		cout << test5.at(i);
	cout << " \nSize = " << test5.getSize() << endl;
	cout << "Capacity = " << test5.getCapacity() << endl; //make sure shrink function

	try //reasonable range
	{
		test5.at(49);
	}
	catch (const outOfRange & error)
	{
		cerr << "Out of Range error :" << error.what() << endl;
	}
	try //reasonable range
	{
		test5.at(100);
	}
	catch (const outOfRange & error)
	{
		cerr << "Out of Range error :" << error.what() << endl;
	}
	try //wrong range
	{
		test5.at(105) = { 5 };
	}
	catch (const outOfRange & error)
	{
		cerr << "Out of Range error :" << error.what() << endl;
	}
	
	cout << "\n----------------Mystring constructor()-------------------";
	cout << "\nStr1 : ";
	MyString str1;
	cout << "\nSize = " << str1.getSize() << endl;
	cout << "Capacity = " << str1.getCapacity() << endl; 
	str1.resize(20, 'c');
	cout << "\nStr1 : " << str1;
	cout << "\nSize = " << str1.getSize() << endl;
	cout << "Capacity = " << str1.getCapacity() << endl;
	
	MyString str2;
	cout << "\nStr2 : " << str2;
	cout << "\nSize = " << str2.getSize() << endl;
	cout << "Capacity = " << str2.getCapacity() << endl;
	str2.resize(15, 'A');
	cout << "\nStr2 : " << str2;
	cout << "\nSize = " << str2.getSize() << endl;
	cout << "Capacity = " << str2.getCapacity() << endl;

	MyString str3;
	cout << "\nStr3 : " << str3;
	cout << "\nSize = " << str3.getSize() << endl;
	cout << "Capacity = " << str3.getCapacity() << endl;
	str3.resize(15, 'B');
	cout << "\nStr3 : " << str3;
	cout << "\nSize = " << str3.getSize() << endl;
	cout << "Capacity = " << str3.getCapacity() << endl;

	cout << "\n----------------substring constructor()-------------------";
	MyString str4(str3, 3, 4);
	cout << "\nStr4 : " << str4;
	cout << "\nSize = " << str4.getSize() << endl;
	cout << "Capacity = " << str4.getCapacity() << endl;
	
	MyString str5(str2, 4, 9);
	cout << "\nStr5 : " << str5;
	cout << "\nSize = " << str5.getSize() << endl;
	cout << "Capacity = " << str5.getCapacity() << endl;

	MyString str6(str1, 5, 11);
	cout << "\nStr6 : " << str6;
	cout << "\nSize = " << str6.getSize() << endl;
	cout << "Capacity = " << str6.getCapacity() << endl;

	cout << "\n---------------- append -------------------";
	str3.append(str2);
	cout << "\nStr3.append(Str2) : " << str3;
	cout << "\nSize = " << str3.getSize() << endl;
	cout << "Capacity = " << str3.getCapacity() << endl;
	
	str4.append(str1);
	cout << "\nStr4.append(Str1) : " << str4;
	cout << "\nSize = " << str4.getSize() << endl;
	cout << "Capacity = " << str4.getCapacity() << endl;

	str6.append(str5);
	cout << "\nStr6.append(Str5) : " << str6;
	cout << "\nSize = " << str6.getSize() << endl;
	cout << "Capacity = " << str6.getCapacity() << endl;

	cout << "\n---------------- substr -------------------";
	str3 = str3.substr(3, 16);
	cout << "\nstr3 = str3.substr(3, 16) : " << str3;
	cout << "\nSize = " << str3.getSize() << endl;
	cout << "Capacity = " << str3.getCapacity() << endl;

	str4 = str6.substr(3, 12);
	cout << "\nstr4 = str6.substr(3, 12) : " << str4;
	cout << "\nSize = " << str4.getSize() << endl;
	cout << "Capacity = " << str4.getCapacity() << endl;

	str5 = str4.substr(2, 9);
	cout << "\nstr5 = str4.substr(2, 9) : " << str5;
	cout << "\nSize = " << str5.getSize() << endl;
	cout << "Capacity = " << str5.getCapacity() << endl;
	
	cout << "\n---------------- insert -------------------\n";
	
	MyString str7;
	str7.resize(10, 'g');
	cout << "Str7 : " << str7 << endl;
	MyString str8;
	str8.resize(5, 'T');
	cout << "Str8 : " << str8 << endl;
	str8.insert(3, str7, 1, 4);
	cout << "Str8.insert(3, Str7, 1, 4) : " << str8 << endl; //T T T  g g g g T T
	
	MyString str9;
	MyString str10;
	str9.resize(6, 'g');
	cout << "Str9 : " << str9 << endl;
	str10.resize(6, 'T');
	cout << "Str10 : " << str10 << endl;
	str10.insert(3, str9);
	cout << "Str10.insert(3, Str9) : " << str10 << endl;
	
	cout << "\n-------------- msize -----------------\n";
	MyString str11;
	MyString str12;
	str11.resize(5, 'p');
	cout << "str11 :" << str11 << endl;
	str12.resize(7, 'G');
	cout << "str12 :" << str12 << endl;
	str11.insert(3, str12, 1);
	cout << "Str11.insert(3, str12, 1) : " << str11 << endl;
	str12 = str12.substr(1); 
	cout << "str12.substr(1) : " << str12 << endl;

	cout << "\n-------------- erase -----------------\n";
	str10.erase(2, 5);
	cout << "str10 :" << str10 << endl;
	str11.erase(2, 4);
	cout << "str11 :" << str11 << endl;
	str12.erase(3); //test msize
	cout << "str12 :" << str12<< endl;
	
	cout << "\n-------------- find -----------------\n";
	cout << "Str6 :" << str6 << endl;
	cout << "Str5 :" << str5 << endl;
	cout << "Str6.find(Str5, 4) : " << str6.find(str5, 4) << endl; //9
	cout << "Str6.find(Str5) : " << str6.find(str5) << endl; //5

	cout << "Str8 :" << str8 << endl;
	cout << "Str7 :" << str7 << endl;
	cout << "Str8.find(Str7, 6) : "<<str8.find(str7, 6) << endl; //3
	cout << "Str8.find(Str7) : " << str8.find(str7) << endl;

	cout << "\n-------------- find_first_of -----------------\n";
	cout << "Str6 :" << str6 << endl;
	cout << "Str5 :" << str5 << endl;
	cout << "Str6.find_first_of(Str5, 6) : " << str6.find_first_of(str5, 6) << endl; //11
	cout << "Str6.find_first_of(Str5) : " << str6.find_first_of(str5) << endl; 

	cout << "Str8 :" << str8 << endl;
	cout << "Str7 :" << str7 << endl;
	cout << "Str8.find_first_of(Str7, 6) : " << str8.find_first_of(str7, 6) << endl;//3
	cout << "Str8.find_first_of(Str7) : " << str8.find_first_of(str7) << endl;

	cout << "\n-------------- const char* s -----------------\n";
	const char* n1 = "abcdefghijklmnopqrstuvwxyz";
	MyString str13(n1);
	cout << "str13 : " << str13 << endl;
	const char* n2 = "whwfasghwfoihq0kjwpogjijopsajdi:'qws,apd";
	MyString str14(n2);
	cout << "str14 : " << str14 << endl;
	const char* n3 = ";asdasdqg;tjfdbvcbw3253wsfd5u64i@^$&$%@!#$!&^%$*$^@d";
	MyString str15(n3);
	cout << "str15 : " << str15 << endl;
	
	const char* n4 = "to be or not to be, that is cool question.";
	MyString str16(n4);
	cout << "str16 : " << str16 << endl;
	const char* n5 = "cool";
	MyString str17(n5);
	cout << "str17 : " << str17 << endl;
	cout << "str16.find(str17) : " << str16.find(str17 ,0) << endl;

	cout << "\n-------------- operator>>-----------------\n";
	MyString str18;
	cin >> str18;
	cout << "Str18 :" << str18 << endl;


	cout << "\n-------------- Exception handling-----------------\n";
	try //reasonable range
	{
		str2.at(14);
	}
	catch (const outOfRange & error)
	{
		cerr << "Out of Range error :" << error.what() << endl;
	}
	
	try //reasonable range
	{
		str3.at(15);
	}
	catch (const outOfRange & error)
	{
		cerr << "Out of Range error :" << error.what() << endl;
	}
	try //wrong range
	{
		str5.at(12);
	}
	catch (const outOfRange & error)
	{
		cerr << "Out of Range error :" << error.what() << endl;
	}
	
	
	return 0;

}