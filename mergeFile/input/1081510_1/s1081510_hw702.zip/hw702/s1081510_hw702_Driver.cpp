#include <iostream>
#include <iomanip> 
#include "s1081510_MyString.h" 
#include <vector>
#include <string>
#include <stdexcept>
using namespace std;

int main()
{
	cout << "My ID is s1081510" << endl;

	MyString str1("happy"), str2(" birthday"), str3("to be question"), str4("the "), str5;
	cout << "str1 = " << str1 << endl;
	cout << "str2 = " << str2 << endl;
	cout << "str3 = " << str3 << endl;
	cout << "str4 = " << str4 << endl;

	cout << endl;

	cout << "str1.append(str2)" << endl;
	str1.append(str2);
	cout << "str1 = " << str1 << endl;

	cout << endl;

	cout << "str5 = str1.substr(11, 3)" << endl;
	str5 = str1.substr(11, 3);
	cout << "str1 = " << str1 << endl;
	cout << "str5 = " << str5 << endl;

	cout << endl;

	cout << "str3.insert(6, str4)" << endl;
	str3.insert(6, str4);
	cout << "str3 = " << str3 << endl;
	MyString str6("or not to be");
	cout << "str6 = " << str6 << endl;
	cout << "str3.insert(6, str6, 3, 4)" << endl;
	str3.insert(6, str6, 3, 4);
	cout << "str3 = " << str3 << endl;

	cout << endl;

	cout << "str3.erase(6, 4)" << endl;
	str3.erase(6, 4);
	cout << "str3 = " << str3 << endl;

	cout << endl;

	MyString str7("to be or not to be, that is cool question"), str8;
	cout << "str7 = " << str7 << endl;
	cin >> str8;
	cout << "str8 = " << str8 << endl;

	cout << endl;

	cout << "str7.find(str8, 0) = " << str7.find(str8, 0) << endl;
	MyString str9;
	cin >> str9;
	cout << "str9 = " << str9 << endl;
	cout << "str7.find_first_of(str9, 0) = " << str7.find_first_of(str9, 0) << endl;

} // end main
