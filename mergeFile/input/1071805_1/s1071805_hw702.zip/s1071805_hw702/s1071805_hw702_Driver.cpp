#include "s1071805_MyArray.h"
#include "s1071805_MyString.h"
#include <iostream>
#include <stdexcept>
#include <vector>
#include <string>
using namespace std;

int main(int argc, char *argv[])
{
	cout << "I'm s1071805" << endl;

	cout << "\n**************Test constructor**************" << endl;
	MyString str1 = "Hapcc", str2 = " fo";
	cout << "str1 = " << str1 << endl;
	cout << "str1.getSize() = " << str1.getSize() << endl;
	cout << "ans = 5" << endl;
	str1.shrink_to_fit();
	str1.reserve(7);
	cout << "str1.getCapacity() = " << str1.getCapacity() << endl;
	cout << "ans = 7" << endl;
	cout << "str2 = " << str2 << endl;
	cout << "str2.getSize() = " << str2.getSize() << endl;
	cout << "ans = 3" << endl;
	cout << "str2.getCapacity() = " << str2.getCapacity() << endl;
	cout << "ans = 10" << endl;

	cout << "\n**************Test assignment operator**************" << endl;
	MyString a;
	cout << "a = " << a << endl;
	cout << "str1 = " << str1 << endl;
	a = str1;
	cout << "a = " << a << endl;
	cout << "ans = Hapcc" << endl;

	cout << "\n**************Test substring constructor**************" << endl;
	MyString b("wxyz", 1, 2);
	cout << "b = " << b << endl;
	cout << "ans = xy" << endl;

	cout << "\n**************Test append()**************" << endl;
	str1.append(str2);
	cout << "str1.append() = " << str1 << endl;
	cout << "str1.getSize() = " << str1.getSize() << endl;
	cout << "ans = 8" << endl;
	cout << "str1.getCapacity() = " << str1.getCapacity() << endl;
	cout << "ans = 14" << endl;

	cout << "\n**************Test substr()**************" << endl;
	MyString str3;
	str3 = str1.substr(3, 4);
	cout << "str3 = " << str3 << endl;
	cout << "ans = cc f" << endl;
	cout << "str3.getSize() = " << str3.getSize() << endl;
	cout << "ans = 4" << endl;
	cout << "str3.getCapacity() = " << str3.getCapacity() << endl;
	cout << "ans = 10" << endl;

	cout << "\n**************Test insert()**************" << endl;
	MyString str4 = "to be question", str5 = "the ", str6 = "abcd"
		, str7 = "to be question", str8 = "or not to be";
	//cout << "str4 = " << str4 << endl;
	//cout << "str5 = " << str5 << endl;
	str4.insert(6, str5);
	cout << "str4.insert() = " << str4 << endl;
	cout << "ans = to be the question" << endl;
	cout << "str4.getSize() = " << str4.getSize() << endl;
	cout << "ans = 18" << endl;
	cout << "str4.getCapacity() = " << str4.getCapacity() << endl;
	cout << "ans = 20" << endl;
	cout << endl;
	//cout << "str3 = " << str3 << endl;
	//cout << "str6 = " << str6 << endl;
	str3.insert(3, str6, 1, 2);
	cout << "str3.insert() = " << str3 << endl;
	cout << "ans = cc bcf" << endl;
	cout << "str3.getSize() = " << str3.getSize() << endl;
	cout << "ans = 6" << endl;
	cout << "str3.getCapacity() = " << str3.getCapacity() << endl;
	cout << "ans = 10" << endl;
	cout << endl;
	//cout << "str7 = " << str7 << endl;
	//cout << "str8 = " << str8 << endl;
	str7.insert(6, str8, 3, 4);
	cout << "str7.insert() = " << str7 << endl;
	cout << "ans = to be the question" << endl;
	cout << "str7.getSize() = " << str7.getSize() << endl;
	cout << "ans = 18" << endl;
	cout << "str7.getCapacity() = " << str7.getCapacity() << endl;
	cout << "ans = 20" << endl;

	cout << "\n**************Test erase()**************" << endl;
	MyString str9 = "ABCDEF";

	str9.erase(2, 2);
	cout << "str9.erase() = " << str9 << endl;
	cout << "ans = ABEF" << endl;
	cout << "str9.getSize()= " << str9.getSize() << endl;
	cout << "ans = 4" << endl;
	cout << "str9.getCapacity()= " << str9.getCapacity() << endl;
	cout << "ans = 10" << endl;

	cout << "\n**************Test find()**************" << endl;
	MyString str10 = "to be or not to be, that is cool question";
	cout << "str10.find() = " << str10.find("cool", 0) << endl;
	cout << "ans = 28" << endl;
	
	cout << "\n**************Test find_first_of()**************" << endl;
	MyString str11 = "to be or not to be, that is cool question";
	cout << "str11.find_first_of() = " << str11.find_first_of("cXXl") << endl;
	cout << "ans = 28" << endl;

	cout << "\n**************Test operator>>**************" << endl;
	MyString str12, str13;
	while (1)
	{
		cout << "str12 = ";
		cin >> str12;
		cout << "str13 = ";
		cin >> str13;
		cout << endl;

		cout << "str12 = " << str12 << endl;
		cout << "str13 = " << str13 << endl;
		cout << endl;
	}
	

	system("pause");
}