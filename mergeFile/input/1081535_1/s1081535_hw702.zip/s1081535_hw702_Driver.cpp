#include<iostream>
#include "s1081535_MyString.h"
using namespace std;

int main() {
	cout << "Hello, I'm s1081535's driver program: " << endl << endl;

	MyString a1, a2("my"), a3("name"), a4("heisugly"), a5(a4, 2, 2), a6(a4, 2), a7(a4, 8, 1);
	cout << "**************Test constructor & operator<< & operator>>  **************" << endl;

	cout << "Enter a string value�G" << endl;
	cin >> a1;
	cout <<"a1 = " <<a1 << endl;

	cout << " a2 = " << a2 << endl;
	cout << "ans = my " << endl;
	cout << endl;
	cout << " a3 = " << a3 << endl;
	cout << "ans = name" << endl;
	cout << endl;
	cout << " a4 = " << a4 << endl;
	cout << "ans = heisugly" << endl;
	cout << endl;
	cout << " a5 = " << a5 << endl;
	cout << "ans = is" << endl;
	cout << endl;
	cout << " a6 = " << a6 << endl;
	cout << "ans = " << endl;
	cout << endl;
	cout << " a7 = " << a7 << endl;
	cout << "ans = " << endl;
	
	cout << "**************Test append   **************" << endl;
	cout << "a2.append(a3) = "<<a2.append(a3) << endl;
	cout << "          ans = myname"  << endl;
	cout << endl;

	MyString a8("mynameisjessie");
	cout << "**************Test substr   **************" << endl;
	cout << " a8 = " << a8 << endl;
	cout << "ans = mynameisjessie" << endl;
	cout << endl;

	cout << "a8.substr(28, 6) = " << a8.substr(28, 6) << endl;
	cout << "             ans = out_of_range." << endl;
	cout << endl;

	cout << "a8.substr(8, 6) = " << a8.substr(8, 6) << endl;
	cout << "            ans = jessie" << endl;
	cout << endl;

	cout << " a8 = " << a8 << endl;
	cout << "ans = mynameisjessie" << endl;
	cout << endl;

	MyString a9("beauful"), a10("ti"), a11("sdfsdeetiiadfw"),a12("beauful");
	cout << "**************Test insert  **************" << endl;
	cout << " a9 = " << a9 << endl;
	cout << "ans = beauful" << endl;
	cout << endl;

	cout << "a9.insert(4, a10) = " << a9.insert(4, a10) << endl;
	cout << "              ans = beautiful" << endl;
	cout << endl;

	cout << " a9 = " << a9 << endl;
	cout << "ans = beautiful" << endl;
	cout << endl;

	cout << "a9.insert(44, a10) = " << a9.insert(44, a10) << endl;
	cout << endl;
	
	cout << " a9 = " << a9 << endl;
	cout << "ans = beautiful" << endl;
	cout << endl;
	
	cout << "a12 = " << a12 << endl;
	cout << "ans = beauful" << endl;
	cout << endl;

	cout << "a12.insert(4, a11,7,2) = " << a12.insert(4, a11,7,2) << endl;
	cout << "                   ans = beautiful" << endl;
	cout << endl;

	cout << "a12.insert(85, a11,7,2) = " << a12.insert(85, a11, 7, 2) << endl;
	cout << endl;

	cout << "a12.insert(4, a11,73,2) = " << a12.insert(4, a11, 73, 2) << endl;
	cout << endl;

	cout << "a12.insert(4, a11,7,21) = " << a12.insert(4, a11, 7, 21) << endl;	
	cout << endl;

	cout << " a12 = " << a12 << endl;
	cout << "ans = beautiful" << endl;
	cout << endl;

	MyString a13("Helloiamjffjhtrfdfessie");
	cout << "**************Test erase  **************" << endl;
	cout << "a13 = " << a13 << endl;
	cout << "ans = Helloiamjffjhtrfdfessie" << endl;
	cout << endl;

	cout << "a13.erase(9, 9) = " << a13.erase(9, 9) << endl;
	cout << "            ans = Helloiamjessie" << endl;
	cout << endl;

	cout << "a13 = " << a13 << endl;
	cout << "ans = Helloiamjessie" << endl;
	cout << endl;

	cout << "a13.erase(45, 9) = " << a13.erase(45, 9) << endl;
	cout << endl;

	cout << "a13.erase(9, 54) = " << a13.erase(9, 54) << endl;
	cout << endl;

	cout << "a13 = " << a13 << endl;
	cout << "ans = Helloiamjessie" << endl;
	cout << endl;

	MyString a14("Hello I am Jessie"), a15("am"), a16("love");
	cout << "**************Test find() & find_first_of()  **************" << endl;
	cout << "a14 = " << a14 << endl;
	cout << "ans = Hello I am Jessie" << endl;
	cout << endl;

	cout << "a15 = " << a15 << endl;
	cout << "ans = am" << endl;
	cout << endl;

	cout << "a16 = " << a16 << endl;
	cout << "ans = love" << endl;
	cout << endl;

	cout << "a14.find(a15) = " << a14.find(a15) << endl;
	cout << "          ans = 8" << endl;
	cout << endl;

	cout << "a14.find_first_of(a16) = " << a14.find_first_of(a16) << endl;
	cout << "                   ans = 1" << endl;
	cout << endl;


	cout << "Finish!!" << endl;

	system("pause");
	return 0;
}