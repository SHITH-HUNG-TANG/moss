#include "s1083313_MyString.h"
#include<iostream>
#include<exception>
using namespace std;
int main() {
    cout << "This is 1083313's hw7-2" << endl;
    cout << "1.Constructor / Destructor" << endl;
    MyString n1;
    n1.resize(16, 'k');
    cout << "n1=" << n1 << endl;
    MyString n2(n1, 11, 3);
    cout << "n2=" << n2 << endl;
    const char* n = "wweerrttyyuuiioo";
    MyString n0(n);
    cout << "n0=" << n0 << endl;

    cout << endl;

    cout << "2.append(�K)" << endl;
    cout << "n2=" << n2 << endl;
    cout << "n0=" << n0 << endl;
    n2.append(n0);
    cout << "n2=" << n2 << endl;

    cout << endl;

    cout << "3.insert" << endl;
    const char* a = "aaaaa";
    const char* b = "bbb";
    const char* c = "cc";
    MyString n3(a), n4(b), n5(c);
    cout << "n3=" << n3 << endl;
    cout << "n4=" << n4 << endl;
    cout << "n5=" << n5 << endl;
    n3.insert(0, n4);
    cout << "n3.insert(0, n4)" << endl;
    cout << "n3=" << n3 << endl;
    cout << "n5.insert(1, n4, 1, 1);" << endl;
    n5.insert(1, n4, 1,1);
    cout << "n5=" << n5 << endl;

    cout << endl;

    cout << "4.substr " << endl;
    const char* d = "abcdef";
    MyString n6(d);
    cout << "n6=" << n6 << endl;
    cout << "n6.substr(1, 3);" << endl;
     cout << "n6=" << n6.substr(1, 3) << endl;

    cout << endl;

    cout << "5.erase" << endl;
    const char* e = "lmnopqrs";
    MyString n7(e);
    const char* f = "qwertyuio";
    MyString n8(f);
    cout << "n7=" << n7 << endl;
    cout << "n8=" << n8 << endl;
    n7.erase(3, 4);
    cout << "n7.erase(3, 4);" << endl;
    cout << n7 << endl;
    cout << "n8.erase(3);" << endl;
    n8.erase(3);
    cout << "n8=" << n8 << endl;

    cout << endl;

    cout << "6.find() and find_first_of() " << endl;
    const char* g = "deabcfgh";
    MyString n9(g);
    const char* h = "ijklmnopqabc";
    MyString n10(h);
    const char* i = "eSgsga";
    MyString n11(i);
    cout << "n9=" << n9 << endl;
    cout << "n10=" << n10 << endl;
    cout << "n11=" << n11 << endl;
    cout<<"n9.find(n10, 9)="<< n9.find(n10, 9)<<endl;
    cout << "n9.find_first_of(n11, 0)=" << n9.find_first_of(n11, 0) << endl;



    cout << endl;

    cout << "7.operator>>, operator<<" << endl;
    MyString n12;
    cout << "input n12:" ;
    cin >> n12;
    cout << "n12=" << n12 << endl;

    cout << endl;

    cout << "8.Exception handling" << endl;

    const char* j = "finallyQAQ";
    MyString n15(j);
    try {
        cout << "n15= " << n15 << endl;
        cout << "n15.at(2)= ";
        cout << n15.at(2);
        cout << endl;
    }
    catch (Out_of_range& ouo)
    {
        cerr << "error:n15.at(2) " << ouo.what() << endl;
    }

    try {
        cout << "n15= " << n15 << endl;
        cout << "n15.at(14)= ";
        cout << n15.at(14);
    }
    catch (Out_of_range& ouo)
    {
        cerr << "error:n15.at(14) " << ouo.what() << endl;
    }
  
    cout << endl;


   
}