#include<iostream>
#include<iomanip>
#include "s1083342_MyArray.h"
#include "s1083342_MyString.h"
int main()
{
	cout << "***********MyString()*******************" << endl;
	MyString  n1;
	cout << n1 << endl;
	cout << n1.getSize() << endl;
	cout << n1.getCapacity() << endl;

	cout << "***********MyString(const T* s)*******************" << endl;
	MyString 	n2("ABC");
	MyString 	n3("DEFGHIJKLMN");
	cout << n2 << endl;
	cout << n3 << endl;
	cout << n2.getSize() << endl;
	cout << n2.getCapacity() << endl;
	cout << n3.getSize() << endl;
	cout << n3.getCapacity() << endl;

	
	cout << "***********MyString(const MyString& str, size_t pos, size_t len = msize)*******************" << endl;
	MyString 	n4(n3, 1, 3);
	cout << n4 << endl;
	cout << n4.getSize() << endl;
	cout << n4.getCapacity() << endl;

	cout << "***********append*******************" << endl;
	n2.append(n3);
	cout << n2 << endl;
	cout << n2.getSize() << endl;
	cout << n2.getCapacity() << endl;

	cout << "***********substr*******************" << endl;
	cout << n2.substr(2, 3) << endl;

	cout << "***********MyString& insert(size_t pos, const MyString& str)*******************" << endl;
	MyString n5("opopopop");
	cout << n2.insert(100, n5) << endl;

	cout << "***********MyString& insert(size_t pos, const MyString& str, size_t subpos, size_t sublen = msize)*******************" << endl;
	MyString n6("sabello");
	cout << n3.insert(2, n6,2,2) << endl;

	cout << "***********erase*******************" << endl;
	cout << n6.erase(2, 2) << endl;

	cout << "***********size_t find(const MyString& str, size_t pos = 0) const*******************" << endl;
	MyString 	n7("Hello I am Emma");
	MyString 	n8("am");
	cout << n7.find(n8, 2) << endl;
	cout << n7.find(n8, 11) << endl;   /*msize*/

	cout << "***********size_t find_first_of(const MyString& str, size_t pos = 0) const*******************" << endl;
	MyString 	n9("Hello I am Emma ,how are you ?");
	MyString  n10("apple");
	cout << n9.find_first_of(n10, 4) << endl;

	cout << "***********istream*******************" << endl;
	cout << "cin a number" << endl;
	MyString 	n11;
	cin >> n11;
	cout << n11 << endl;

}