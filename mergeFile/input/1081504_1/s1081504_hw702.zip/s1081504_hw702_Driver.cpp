#include<iostream>
#include "s1081504_MyString.h"

using namespace std;

int main(int argc, char* argv[])
{
	MyString n1;
	char c1[] = "Hello, this is 1081504's driver program.";
	MyString n2(c1);
	MyString n3(c1, 15, 7);
	MyString n4(n2);
	char c2[] = "Hello World!";
	MyString n5(c2);
	MyString n6(c2, 6, 5);


	cout << "Hello, this is 1081504's driver program: " << endl << endl;

	cout << "**************Test constructor**************" << endl;
	cout << "n1 = " << n1 << endl;
	cout << "ans= " << endl;
	cout << "n2 = " << n2 << endl;
	cout << "ans= Hello, this is 1081504's driver program." << endl;
	cout << "n3 = " << n3 << endl;
	cout << "ans= 1081504" << endl;
	cout << "n4 = " << n4 << endl;
	cout << "ans= Hello, this is 1081504's driver program." << endl;
	cout << "n5 = " << n5 << endl;
	cout << "ans= Hello World!" << endl;
	cout << "n6 = " << n6 << endl;
	cout << "ans= World" << endl;

	cout << "\n**************Test Functions**************" << endl;
	cout << "\nTesting append()" << endl;

	char c3[] = "Hello, this is 1081504's driver program.";
	char c4[] = " Welcome!";
	MyString n7(c3);
	MyString n8(c4);

	n7.append(n8);
	cout << "n7 = " << n7 << endl;
	cout << "ans= Hello, this is 1081504's driver program. Welcome!\n";


	cout << "\nTesting substr()" << endl;

	MyString n9(c3);

	cout << "substr = " << n9.substr(15, 7) << endl;
	cout << "   ans = 1081504\n";
	

	cout << "\nTesting insert()" << endl;
	char c5[] = "not ";
	char c6[] = "wasd";
	MyString n10(c3);
	MyString n11(c5);
	MyString n12(c6);

	n10.insert(15, n11);
	cout << "n10 = " << n10 << endl;
	cout << "ans = Hello, this is not 1081504's driver program.\n";
	n10.insert(19, n12, 2, 1);
	cout << "n11 = " << n10 << endl;
	cout << "ans = Hello, this is not s1081504's driver program.\n";


	cout << "\nTesting erase()" << endl;

	MyString n13(c3);
	MyString n14(n9);

	n13.erase(0, 7);
	cout << "n13 = " << n13 << endl;
	cout << "ans = this is 1081504's driver program.\n";
	n14.erase(0);
	cout << "n14 = " << n14 << endl;
	cout << "ans =\n";


	cout << "\nTesting find()" << endl;

	MyString n15(c3);
	char c7[] = "1081504";
	MyString n16(c7);
	cout << "find = " << n15.find(n16) << endl;
	cout << " ans = 15\n";
	char c8[] = "2081504";
	MyString n17(c8);
	cout << "find = ";
	if (n15.find(n17) == n15.msize)
		cout << "not found\n";
	else
		cout << n15.find(n17) << endl;
	cout << " ans = not found\n";


	cout << "\nTesting find_fisrt_of()" << endl;

	MyString n18(c3);
	char c9[] = "123456";
	MyString n19(c9);
	cout << "find = " << n18.find_first_of(n19) << endl;
	cout << " ans = 15\n";
	char c10[] = "FIRST";
	MyString n20(c10);
	cout << "find = ";
	if (n18.find_first_of(n20) == n18.msize)
		cout << "not found\n";
	else
		cout << n18.find_first_of(n20) << endl;
	cout << " ans = not found\n";
	

	system("pause");
	return 0;
}