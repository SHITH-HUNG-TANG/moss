#include"s1081543_MyString.h"

#include<iostream>

using namespace std;

int main()
{
	cout << "1081543's Driver" << endl;

	cout << "----------------Test Constructor--------------------" << endl;

	char c1[] = "hello happy ya ya ! ";
	MyString s1(c1);
	cout << "s1 = "  << s1 << endl;
	cout << "ans= hello happy ya ya ! " << endl;

	MyString s2(s1);
	cout << "s2 = " << s2 << endl;
	cout <<"ans= hello happy ya ya ! " << endl;

	MyString s3(s1, 0, 5);
	cout << "s3 = " << s3 << endl;
	cout << "ans= hello" << endl;

	MyString s4(s1, 6);
	cout << "s4 = " << s4 << endl;
	cout << "ans= happy ya ya ! " << endl;

	cout << endl << endl;

	cout << "----------------Test append--------------------" << endl;

	s1.append(s2);
	cout << "s1.append(s2) = " << s1 << endl;
	cout << "           ans= hello happy ya ya ! hello happy ya ya !" << endl;
	
	char c2[] = "Hey ! ";
	MyString s5(c2);
	cout << "s2 = " << s5 << endl;
	cout << "ans= Hey ! " << endl;
	s5.append(s1);
	cout << "s5.append(s1) = " << s5 << endl;
	cout << "           ans= Hey ! hello happy ya ya ! hello happy ya ya ! " << endl;

	cout << endl << endl;


	cout << "----------------Test substr--------------------" << endl;
	
	cout << "s5.substr(0, 11) = " << s5.substr(0, 11) << endl;
	cout << "             ans = Hey ! hello" << endl;
	cout << "s5.substr(12) = " << s5.substr(12) << endl;
	cout << "          ans = happy ya ya ! hello happy ya ya ! " << endl;

	cout << endl << endl;

	cout << "----------------Test insert--------------------" << endl;

	char c3[] = "to be question";
	char c4[] = "the ";
	MyString s6(c3);
	MyString s7(c4);
	cout << "s6 = " << s6 << endl;
	cout << "ans= to be question" << endl;
	cout << "s7 = " << s7 << endl;
	cout << "ans= the " << endl;
	s6.insert(6, s7);
	cout << "s6.insert(6, s7) = " << s6 << endl;
	cout << "             ans = to be the question" << endl;

	cout << endl << endl;

	cout << "----------------Test another insert--------------------" << endl;

	// example: str = "to be the question", str3 = "or not to be"
	// str.insert(6,str3,3,4); // to be (not )the question
	char c5[] = "to be the question";
	char c6[] = "or not to be";
	MyString s8(c5);
	MyString s9(c6);
	cout << "s8 = " << s8 << endl;
	cout << "ans= " << "to be the question" << endl;
	cout << "s9 = " << s9 << endl;
	cout << "ans= or not to be" << endl;
	s8.insert(6, s9, 3, 4);
	cout << "s8.insert(6, s9, 3, 4) = " << s8 << endl;
	cout << "                   ans = to be not the question" << endl;

	cout << endl << endl;

	cout << "----------------Test erase--------------------" << endl;
	char c7[] = "I am 1081543's Driver program";
	MyString s10(c7);
	cout << "s10 = " << s10 << endl;
	cout << "ans = I am 1081543's Driver program" << endl;
	s10.erase(5, 10);
	cout << "s10.eraser(5,10) = " << s10 << endl;
	cout << "             ans = I am Driver program" << endl;
	s10.erase(4);
	cout << "s10.eraser(4) = " << s10 << endl;
	cout << "          ans = I am" << endl;

	cout << endl << endl;


	cout << "----------------Test find--------------------" << endl;

	char c8[] = "to be or not to be, that cool is question";
	MyString s11(c8);
	cout << "s11 = " << s11 << endl;
	cout << "ans = to be or not to be, that cool is question" << endl;
	cout << "find cool" << endl;
	char c9[] = "cool";
	MyString s12(c9);
	if (s11.find("cool") == 4294967295)
	{
		cout << "       not found" << endl;
	}
	else
	{
		cout << "    cool is at "<<s11.find(s12) << endl;
	}
	cout << "ans cool is at 25" << endl;

	if (s11.find("apple") == 4294967295)
	{
		cout << "       not found" << endl;
	}
	else
	{
		cout << "    cool is at " << s11.find("apple") << endl;
	}
	cout << "ans is not found" << endl;

	cout << endl << endl;

	cout << "----------------Test find first of--------------------" << endl;

	char c10[] = "to be adXX or not to be Lcxx, that is cool question";
	MyString s13(c10);
	cout << "s13 = " << s13 << endl;
	cout << "ans = to be adXX or not to be Lcxx, that is cool question" << endl;
	cout << "find cXXL" << endl;
	if (s13.find_first_of("cXXL") == 4294967295)
	{
		cout << "       not found" << endl;
	}
	else
	{
		cout << "    cXXL is at " << s13.find_first_of("cXXL") << endl;
	}
	cout << "ans cXXL is at 8" << endl;
	if (s13.find_first_of("cXXL",10) == 4294967295)
	{
		cout << "       not found" << endl;
	}
	else
	{
		cout << "    cXXL is at " << s13.find_first_of("cXXL", 10) << endl;
	}
	cout << "ans cXXL is at 24" << endl;

	cout << "ZZBBA" << endl;
	if (s13.find_first_of("ZZBBA") == 4294967295)
	{
		cout << "       not found" << endl;
	}
	else
	{
		cout << "ZZBBA is at " << s13.find_first_of("ZZBBA", 10) << endl;
	}
	cout << "ans is not found" << endl;

	cout << endl << endl;

	cout << "----------------Test operator>>--------------------" << endl;

	MyString s14;

	cin >> s14;

	cout << s14 << endl;

	system("pause");

	return 0;
}