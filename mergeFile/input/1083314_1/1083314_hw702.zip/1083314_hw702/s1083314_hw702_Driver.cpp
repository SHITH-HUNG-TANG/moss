#include<iostream>
#include<string>
#include "s1083314_MyArray.h"
#include "s1083314_MyString.h"

using namespace std;

int main() {
	
	cout << "Hello 1083314, I'm driver program: " << endl << endl;

	cout << "**************Constructor / Destructor**************" << endl;

	MyString<char> n1;
	n1.resize(10, 'a');
	cout << "n1 = aaaaaaaaaa" << endl;
	cout << "n1 = " << n1 << endl;

	MyString<char> str0("Capacity");
	MyString<char>n2(str0, 2, 3);
	cout << "n2 = pac" << endl;
	cout << "n2 = " << n2 << endl << endl;


	cout << "**************MyString& append(const MyString& str)**************" << endl;
	MyString<char> str1("write");
	n2.append(str1);
	cout << "n2 = pacwrite" << endl;
	cout << "n2 = " << n2 << endl << endl;


	cout << "**************MyString substr(size_t pos, size_t len = msize) const**************" << endl;
	MyString<char> n3;
	n3 = n2.substr(3,3);
	cout << "n3 = wri" << endl;
	cout << "n3 = " << n3 << endl << endl;
	//cout << n3.getSize() << n3.getCapacity() << endl;


	cout << "**************MyString& insert(size_t pos, const MyString& str)**************" << endl;
	MyString<char> n4;
	n4 = n3.insert(1, str1);
	cout << "n4 = wwriteri" << endl;
	cout << "n4 = " << n4 << endl << endl;

	/*MyString<char> str2("ite ");
	MyString<char> n5;
	cout << n3 << endl;
	cout << str2 << endl;
	n5 = n3.insert(1, str2);
	cout << "iite writete" << endl;
	cout << n5 << endl;*/


	cout << "*******MyString& insert(size_t pos, const MyString& str, size_t subpos, size_t sublen = msize)*******" << endl;
	MyString<char>n6("The sixth passed");
	MyString<char>n7("abcis ");
	cout << "n6 = The sixth is passed" << endl;
	cout << "n6 = " << n6.insert(10, n7, 3, 3) << endl << endl;


	cout << "**************MyString& erase(size_t pos, size_t len = msize)**************" << endl;
	MyString<char>n8("The eighth is is passed");
	cout << "n8 = The eighth is passed" << endl;
	cout << "n8 = " << n8.erase(13, 3) << endl << endl;



	cout << "**************size_t find(const MyString& str, size_t pos = 0) const**************" << endl;
	MyString<char>n9("to be or not to be, that is cool question");
	cout << "n9 = " << n9 << endl;
	cout << "find cool in n9 = " << n9.find("cool",28) <<endl;//29?
	cout << "find cxxl in n9 = " << n9.find("cxxl", 28) << endl << endl;


	cout << "**************size_t find_first_of(const MyString& str, size_t pos = 0) const**************" << endl;
	MyString<char>n10("to be or not to be, Lhat is Xool question");
	cout << "n10 = " << n10 << endl;
	cout << "find cXXL in n10 = " << n10.find_first_of("cXXL") << endl;
	cout << "find cXXL  in n10 = " << n10.find_first_of("cXXL ") << endl << endl;


	cout << "**************operator>>, operator<<**************" << endl;
	MyString<char>n11;
	cin >> n11;
	cout << n11 << endl << endl;


	cout << "**************Exception handling**************" << endl;
	try {
		cout << n11.at(100000) << endl << endl;
	}
	catch (MyArray<char>::ErrorNumber& e) {
		cout << "n11.at(100000) = " << e.what() << endl << endl;
	}

	system("pause");
	return 0;
	
}