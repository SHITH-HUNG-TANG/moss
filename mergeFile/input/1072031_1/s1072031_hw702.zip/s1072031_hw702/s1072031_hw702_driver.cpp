#include "s1072031_MyArray.h"
#include "s1072031_MyString.h"
#include <iostream>
#include <stdexcept>
using namespace std;
int main()
{
	cout << "----------test = operator and << operator----------" << endl;
	MyString str1 = "123456", str2 = "abcdef";
	cout << str1 << endl;
	cout << str2 << endl;
	cout << "-------------------------------" << endl;


	cout << "----------test append----------" << endl;
	MyString str3 = "Hapcc", str4 = " fo";
	str3.append(str4);
	cout << str3 << endl;
	cout << "-------------------------------" << endl;
	

	cout << "----------test substr----------" << endl;
	MyString str5 = "Hapcc fo", str6;
	str6 = str5.substr(3, 4);
	cout << str6 << endl;
	cout << "-------------------------------" << endl;


	cout<< "----------test insert----------" << endl;
	MyString str7 = "to be question", str8 = "the ";
	str7.insert(6,str8);
	cout << str7 << endl;

	MyString str9 = "to be the question", str10 = "or not to be";
	str9.insert(6,str10,3,4);
	cout << str9 << endl;
	cout << "-------------------------------" << endl;

	cout << "----------test erase----------" << endl;
	MyString str11 = "abcdefg";
	str11.erase(3, 2);
	cout << str11 << endl;
	cout<< "-------------------------------" << endl;

	cout << "----------test find----------" << endl;
	MyString str12 = "to be or not to be, that is cool question";
	cout << str12.find("cool", 0) << endl;
	cout << str12.find("to", 0) << endl;
	cout << str12.find("happy", 0) << endl;
	cout << "-------------------------------" << endl;


	cout << "----------test find_first_of----------" << endl;
	MyString str13 = "to be or not to be, that is cool question";
	cout << str13.find_first_of("cXXL", 0) << endl;
	cout << str13.find_first_of("ZXXA", 0) << endl;
	cout << "-------------------------------" << endl;

	system("pause");
	return 0;
}