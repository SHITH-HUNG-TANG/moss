#include<iostream>
#include"s1083320_MyArray.h"
#include "s1083320_MyString.h"
using namespace std;
int main()
{
	MyString<char> a, b, j("89732");
	cout << "cin >> a = ";
	cin >> a;
	cout << "       a = " << a << endl << endl;

	cout << "cin >> b = ";
	cin >> b;
	cout << "       b = " << b << endl << endl;

	cout << "----------test append()--------------" << endl << endl;
	cout << "       a = " << a << endl;
	cout << "       b = " << b << endl;
	cout << "       j = " << j << endl;
	cout << " a.append(b)" << endl;
	a.append(b);
	cout << "   now a = " << a << endl;
	cout << "       b = " << b << endl << endl;
	cout << " j.append(b)" << endl;
	j.append(b);
	cout << "   now j = " << j << endl << endl;

	cout << "-------------test constructor-----------" << endl << endl;
	const char arr[5] = { 'a','b','c','d','\0' };
	cout << "char arr[5] = { 'a','b','c','d' };" << endl;
	cout << "c(a,2,2), d(arr)" << endl;
	MyString<char> c(a,2,2), d(arr);
	cout << "  c = " << c << endl;
	cout << "  d = " << d << endl;


	cout << "-----------------test substr-------------" << endl << endl;
	MyString<char> e;
	cout << "     cin >> e = ";
	cin >> e;
	cout << "e.substr(2,5) = " << e.substr(2,5) << endl;
	cout << "e.insert(2,a)" << endl;
	e.insert(2, a);
	cout << "**---** now e = " << e << endl;
	cout << "e.insert(2,a,2,3)" << endl;
	e.insert(2, a, 2, 3);
	cout << "**---** now e = " << e << endl;

	cout << "a.find(e,5)" << endl;
	cout << a.find(e, 5) << endl;
	cout << "a.find_first_of(e,5)" << endl;
	cout << a.find_first_of(e, 5) << endl;

	cout << "b.find(e,5)" << endl;
	cout << b.find(e, 5) << endl;
	cout << "b.find_first_of(e,5)" << endl;
	cout << b.find_first_of(e, 5) << endl;
	system("pause");
	return 0;
}