#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <exception>

#include "s1083331_MyArray.h"
#include "s1083331_MyString.h"

using namespace std;

int main(int argc, char* argv[])
{
	cout << " **************** Welcome to my Driver Program ! ! ! ***************" << endl;
	cout << "------------------------------------------------------------------------------------------------------------------------" << endl;
	cout << "<<< ���� MyArray' functions �\�� >>>" << endl;
	cout << endl;

	cout << "**************Test constructor**************" << endl;
	MyArray<int> a(7);
	MyArray<int> b;
	cout << "  a = " << a << endl;
	cout << "ans = is empty" << endl;
	cout << "  b = " << b << endl;
	cout << "ans = is empty" << endl;

	cout << endl;
	cout << "**************Test getSize() function**************" << endl;
	cout << endl;
	cout << "a.getSize() = " << a.getSize() << endl;
	cout << "        ans = 0" << endl;
	cout << "b.getSize() = " << b.getSize() << endl;
	cout << "        ans = 0" << endl;

	cout << endl;
	cout << "**************Test getCapacity() function**************" << endl;
	cout << endl;
	cout << "a.getCapacity() = " << a.getCapacity() << endl;
	cout << "            ans = 7" << endl;
	cout << "b.getCapacity() = " << b.getCapacity() << endl;
	cout << "            ans = 10" << endl;

	cout << endl;
	cout << "**************Test resize()**************" << endl;
	cout << endl;
	cout << "let a's size = 8 and b's size = 6" << endl;
	a.resize(8, 0);
	cout << "a.getSize() = " << a.getSize() << endl;
	cout << "        ans = 8" << endl;
	cout << "a.getCapacity() = " << a.getCapacity() << endl;
	cout << "            ans = 14" << endl;
	cout << "  a = " << a << endl;
	cout << "ans = 0, 0, 0, 0, 0, 0, 0, 0" << endl;
	b.resize(16, 0);
	cout << "b.getSize() = " << b.getSize() << endl;
	cout << "        ans = 16" << endl;
	cout << "b.getCapacity() = " << b.getCapacity() << endl;
	cout << "            ans = 20" << endl;
	cout << "  b = " << b << endl;
	cout << "ans = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0" << endl;
	cout << "let a's size = 8 and b's size = 6" << endl;
	a.resize(2, 0);
	cout << "a.getSize() = " << a.getSize() << endl;
	cout << "        ans = 2" << endl;
	cout << "a.getCapacity() = " << a.getCapacity() << endl;
	cout << "            ans = 14" << endl;
	cout << "  a = " << a << endl;
	cout << "ans = 0, 0" << endl;


	cout << endl;
	cout << "**************Test == and != function**************" << endl;
	cout << endl;
	cout << "if a equal to b or not" << endl;
	cout << endl;
	if (a == b)
	{
		cout << "       equal" << endl;;
	}
	else if (a != b)
	{
		cout << "      not equal" << endl;
	}
	cout << "ans = not equal" << endl;

	cout << endl;
	cout << "**************Test assignment function**************" << endl;
	cout << endl;
	cout << "let a equal to b" << endl;
	cout << endl;
	a = b;
	cout << "a.getSize() = " << a.getSize() << endl;
	cout << "b.getSize() = " << b.getSize() << endl;
	cout << "        ans = 16" << endl;
	cout << "a.getCapacity() = " << a.getCapacity() << endl;
	cout << "b.getCapacity() = " << b.getCapacity() << endl;
	cout << "            ans = 20" << endl;
	cout << "  a = " << a << endl;
	cout << "ans = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0" << endl;
	cout << "  b = " << b << endl;
	cout << "ans = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0" << endl;

	cout << endl;
	cout << "**************Test == and != function**************" << endl;
	cout << endl;
	cout << "if a equal to b or not" << endl;
	cout << endl;
	if (a == b)
	{
		cout << "      equal" << endl;;
	}
	else if (a != b)
	{
		cout << "      not equal" << endl;
	}
	cout << "ans = equal" << endl;
	cout << endl;

	cout << endl;
	cout << "**************Test reserve()**************" << endl;
	cout << endl;
	cout << "let a's size = 18 and b's size = 2" << endl;
	a.resize(18, 0);
	cout << "a.getSize() = " << a.getSize() << endl;
	cout << "        ans = 18" << endl;
	cout << "a.getCapacity() = " << a.getCapacity() << endl;
	cout << "            ans = 20" << endl;
	b.resize(2, 0);
	cout << "b.getSize() = " << b.getSize() << endl;
	cout << "        ans = 2" << endl;
	cout << "b.getCapacity() = " << b.getCapacity() << endl;
	cout << "            ans = 20" << endl;

	cout << endl;
	cout << "**************Test shrink_to_fit()**************" << endl;
	cout << endl;
	cout << "call b's shrink_to_fit()" << endl;
	b.shrink_to_fit();
	cout << "b.getSize() = " << b.getSize() << endl;
	cout << "        ans = 2" << endl;
	cout << "b.getCapacity() = " << b.getCapacity() << endl;
	cout << "            ans = 2" << endl;


	cout << endl;
	cout << "**************Test clear() & isEmpty()**************" << endl;
	cout << endl;
	cout << "if a is empty or not" << endl;
	if (a.isEmpty())
	{
		cout << "      a is empty" << endl;
	}
	else
	{
		cout << "      a is not empty" << endl;
	}
	cout << "ans = a is not empty" << endl;
	cout << endl;
	a.clear();
	cout << "clear a" << endl;
	cout << "if a is empty or not" << endl;
	if (a.isEmpty())
	{
		cout << "      a is empty" << endl;
	}
	else
	{
		cout << "      a is not empty" << endl;
	}
	cout << "ans = a is empty" << endl;

	cout << endl;
	cout << "<<< ���� MyArray' functions �\�൲�� >>>" << endl;
	cout << endl;
	cout << endl;
	cout << endl;

	cout << endl;
	cout << "<<< ���� template class MyArray >>>" << endl;
	cout << endl;

	cout << endl;
	cout << "**************Test template class MyArray constructor**************" << endl;
	cout << endl;

	MyArray<int> c(14, 1);
	cout << "c<int> = " << c << endl;
	cout << "   ans = 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1" << endl;

	MyArray<int> d(5, 3);
	cout << "d<int> = " << d << endl;
	cout << "   ans = 3, 3, 3, 3, 3" << endl;

	MyArray<char> e(14, 'e');
	cout << "e<char> = " << e << endl;
	cout << "    ans = e, e, e, e, e, e, e, e, e, e, e, e, e, e" << endl;

	MyArray<char> f(5, 'f');
	cout << "f<char> = " << f << endl;
	cout << "    ans = f, f, f, f, f" << endl;

	cout << endl;
	cout << "**************Test operator+**************" << endl;
	cout << endl;
	cout << "c + d = " << c + d << endl;
	cout << "  ans = 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3" << endl;
	cout << "e + f = " << e + f << endl;
	cout << "  ans = e, e, e, e, e, e, e, e, e, e, e, e, e, e, f, f, f, f, f" << endl;

	cout << endl;
	cout << "**************Test operator+=**************" << endl;
	cout << endl;
	c += d;
	cout << "  c = " << c << endl;
	cout << "ans = 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 3, 3, 3" << endl;
	e += f;
	cout << "  e = " << e << endl;
	cout << "ans = e, e, e, e, e, e, e, e, e, e, e, e, e, e, f, f, f, f, f" << endl;

	cout << endl;
	cout << "**************Test operator[] **************" << endl;
	cout << endl;
	cout << "c[5] = " << c[5] << endl;
	cout << " ans = 1" << endl;
	cout << "c[16] = " << c[16] << endl;
	cout << "  ans = 3" << endl;
	cout << endl;
	cout << "e[5] = " << e[5] << endl;
	cout << " ans = e" << endl;
	cout << "e[16] = " << e[16] << endl;
	cout << "  ans = f" << endl;
	cout << e[20];

	cout << endl;
	cout << "**************Test at() **************" << endl;
	cout << endl;
	cout << "c.at(5) = " << c.at(5) << endl;
	cout << "    ans = 1" << endl;
	cout << "c.at(16) = " << c.at(16) << endl;
	cout << "     ans = 3" << endl;
	cout << endl;
	cout << "e.at(5) = " << e.at(5) << endl;
	cout << "    ans = e" << endl;
	cout << "e.at(16) = " << e.at(16) << endl;
	cout << "     ans = f" << endl;

	cout << endl;
	cout << "**************Test at() (out of range) **************" << endl;
	cout << endl;
	cout << "c.getSize() = " << c.getSize() << endl;
	try
	{
		cout << "c.at(20) = " << c.at(20) << endl;
	}
	catch (const MyArray<int>::Error& c)
	{
		cout << "c.at(20) = " << c.what() << endl;
	}
	cout << "     ans = out of range" << endl;
	cout << endl;
	cout << "e.getSize() = " << c.getSize() << endl;
	try
	{
		cout << "e.at(20) = " << e.at(20) << endl;
	}
	catch (const MyArray<char>::Error& e)
	{
		cout << "e.at(20) = " << e.what() << endl;
	}
	cout << "     ans = out of range" << endl;

	cout << endl;
	cout << "<<< ���� template class MyArray ����>>>" << endl;
	cout << endl;

	cout << endl;
	cout << endl;
	cout << "<<< ���� MyString's functions �\�� >>>" << endl;
	cout << endl;
	cout << endl;

	cout << endl;
	cout << "**************Test MyString's constructor & operator>>/<<**************" << endl;
	cout << endl;

	char x[13] = { "Hello!World!" };
	MyString g(x);
	cout << "  g = " << g << endl;
	cout << "ans = H, e, l, l, o, !, W, o, r, l, d, !" << endl;
	MyString h(g, 0, 6);
	cout << "  h = " << h << endl;
	cout << "ans = H, e, l, l, o, !" << endl;
	MyString i;
	cout << "  i = " << i << endl;
	cout << "ans = is empty" << endl;
	cout << endl;
	cout << "Please cin i" << endl;
	cin >> i;
	cout << i << endl;
	MyString j(h);
	cout << "  j = " << j << endl;
	cout << "ans = H, e, l, l, o, !" << endl;

	cout << endl;
	cout << "**************Test append() & substr()**************" << endl;
	cout << endl;

	h.append(j);
	cout << "h.append(j)" << endl;
	cout << "  h = " << h << endl;
	cout << "ans = H, e, l, l, o, !,  , H, e, l, l, o, !" << endl;

	cout << "h.substr(7, 6)" << endl;
	cout << "h.substr(7, 6) = " << h.substr(7, 6) << endl;
	cout << "           ans = H, e, l, l, o, !" << endl;

	cout << endl;
	cout << "**************Test insert()**************" << endl;
	cout << endl;

	h.insert(6, j);
	cout << "h.insert(6, j)" << endl;
	cout << "  h = " << h << endl;
	cout << "ans = H, e, l, l, o, !, H, e, l, l, o, !,  , H, e, l, l, o, !" << endl;

	h.insert(6, g, 6, 11);
	cout << "h.insert(6, g, 6, 11)" << endl;
	cout << "  h = " << h << endl;
	cout << "ans = H, e, l, l, o, !, W, o, r, l, d, !, H, e, l, l, o, !,  , H, e, l, l, o, !" << endl;

	cout << endl;
	cout << "**************Test erase()**************" << endl;
	cout << endl;

	h.erase(12, 6);
	cout << "h.erase(12, 6)" << endl;
	cout << "  h = " << h << endl;
	cout << "ans = H, e, l, l, o, !, W, o, r, l, d, !,  , H, e, l, l, o, !" << endl;

	cout << endl;
	cout << "**************Test find() & find_first_of()**************" << endl;
	cout << endl;

	cout << "h = " << h << endl;
	cout << "j = " << j << endl;
	cout << endl;
	cout << "find j in h from 0" << endl;
	cout << "find j at position(-1 is not found) = " << h.find(j, 0) << endl;
	cout << "                                ans = 0" << endl;
	cout << "find j in h from 4" << endl;
	cout << "find j at position(-1 is not found) = " << h.find(j, 4) << endl;
	cout << "                                ans = 13" << endl;
	cout << "find j in h from 15" << endl;
	cout << "find j at position(-1 is not found) = " << h.find(j, 15) << endl;
	cout << "                                ans = -1" << endl;

	cout << "find first of j in h from 0" << endl;
	cout << "find first of j at position(-1 is not found) = " << h.find_first_of(j, 0) << endl;
	cout << "                                         ans = 0" << endl;
	cout << "find first of j in h from 4" << endl;
	cout << "find first of j at position(-1 is not found) = " << h.find_first_of(j, 4) << endl;
	cout << "                                         ans = 4" << endl;
	cout << "find first of j in h from 19" << endl;
	cout << "find first of j at position(-1 is not found) = " << h.find_first_of(j, 19) << endl;
	cout << "                                         ans = -1" << endl;

	cout << endl;
	cout << "Finish!!" << endl;


	system("pause");
	return 0;
}