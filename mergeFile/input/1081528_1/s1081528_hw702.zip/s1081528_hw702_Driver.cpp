#include <iostream>
#include "s1081528_MyString.h"
using namespace std;

int main() {
	cout << "Hello, I'm driver program of 1081528: " << endl << endl;

	cout << "*******************************************Test constructor******************************************" << endl;
	MyString s1, s2("say hello to the world"), s3(s2), s4(s3, 0, 12), s5(s2, 12, 10);
	cout << "The size of s1 = " << s1.getSize() << endl;
	cout << "           ans = 0" << endl;
	cout << "The capacity of s1 = " << s1.getCapacity() << endl;
	cout << "               ans = 10" << endl;
	cout << "s1 = " << s1 << endl;
	cout << "ans= " << endl << endl;

	cout << "The size of s2 = " << s2.getSize() << endl;
	cout << "           ans = 23" << endl;
	cout << "The capacity of s2 = " << s2.getCapacity() << endl;
	cout << "               ans = 40" << endl;
	cout << "s2 = " << s2 << endl;
	cout << "ans= say hello to the world" << endl << endl;

	cout << "s3 = " << s3 << endl;
	cout << "ans= say hello to the world" << endl << endl;

	cout << "The size of s4 = " << s4.getSize() << endl;
	cout << "           ans = 12" << endl;
	cout << "The capacity of s4 = " << s4.getCapacity() << endl;
	cout << "               ans = 20" << endl;
	cout << "s4 = " << s4 << endl;
	cout << "ans= say hello to" << endl << endl;

	cout << "s5 = " << s5 << endl;
	cout << "ans=  the world" << endl << endl;

	cout << "************************************Test append(const MyString &)************************************" << endl;
	MyString s6(", but don't say goodbye");
	s2.append(s6);
	cout << "s2 = " << s2 << endl;
	cout << "ans= say hello to the world, but don't say goodbye" << endl << endl;

	cout << "******************************Test substr(size_t pos, size_t len) const******************************" << endl;
	MyString s7;
	s7 = s2.substr(28, 10);
	cout << "s7 = " << s7 << endl;
	cout << "ans= don't say" << endl << endl;

	cout << "******************************Test insert(size_t pos, const MyString &)******************************" << endl;
	MyString s8(" or hi");
	s3.insert(9, s8);
	cout << "s3 = " << s3 << endl;
	cout << "ans= say hello or hi to the world" << endl << endl;

	cout << "***************Test insert(size_t pos, const MyString &, size_t subpos, size_t sublen)***************" << endl;
	MyString s9("Are you happy or sad?");
	s3.insert(22, s9, 7, 6);
	cout << "s3 = " << s3 << endl;
	cout << "ans= say hello or hi to the happy world" << endl << endl;

	cout << "**********************************Test erase(size_t pos, size_t len)*********************************" << endl;
	s3.erase(3, 9);
	cout << "s3 = " << s3 << endl;
	cout << "ans= say hi to the happy world" << endl << endl;

	cout << "****************************Test find(const MyString &, size_t pos) const****************************" << endl;
	MyString s10("sad");
	cout << "The position of ' the world' in s2 = " << s2.find(s5) << endl;
	cout << "                               ans = 12" << endl;
	cout << "The position of 'sad' in s2 = " << s2.find(s9) << endl;
	cout << "                        ans = msize" << endl << endl;

	cout << "************************Test find_first_of(const MyString &, size_t pos) const***********************" << endl;
	MyString s11("hope"), s12("me");
	cout << "The position of one charactor of 'hope' in s3(from position 10) = " << s3.find_first_of(s11, 10) << endl;
	cout << "                                                            ans = 11" << endl;
	cout << "The position of one charactor of 'hope' in s3 = " << s3.find_first_of(s11) << endl;
	cout << "                                          ans = 4" << endl;
	cout << "The position of one charactor of 'me' in s3(from postion 15) = " << s3.find_first_of(s12, 15) << endl;
	cout << "                                                         ans = msize" << endl << endl;

	cout << "*****************************************Test input & output*****************************************" << endl;
	MyString s13;
	cin >> s13;
	cout << "s13 = " << s13 << endl;

	cout << "***************************************Test Exception handling***************************************" << endl;
	s3.insert(100, s9, 40, 4);
	s3.erase(100);
	s3.find(s10, 100);

	return 0;
}